import { generateSigner, percentAmount, publicKey, some } from "@metaplex-foundation/umi";
import {
  collectionDetails,
  createNft,
  findMetadataPda,
  verifyCollectionV1,
} from "@metaplex-foundation/mpl-token-metadata";
import { makeConnection, loadOrCreatePayer, makeUmiWithPayer, info, section, step, maybeEnv } from "../helpers";

export async function runCollectionVerifyDemo(): Promise<void> {
  section("Demo 2 — create collection and verify NFT");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);
  const rpc = process.env.SOLANA_RPC?.trim() || "https://api.devnet.solana.com";
  const { umi } = makeUmiWithPayer(rpc, payer);

  const collectionMint = generateSigner(umi);
  const nftMint = generateSigner(umi);

  step("Creating collection NFT");
  await createNft(umi, {
    mint: collectionMint,
    name: maybeEnv("COLLECTION_NAME") || "Lecture 15 Collection",
    symbol: maybeEnv("NFT_SYMBOL") || "L15",
    uri: maybeEnv("COLLECTION_URI") || "https://example.com/lecture-15-collection.json",
    sellerFeeBasisPoints: percentAmount(5),
    isCollection: true,
    collectionDetails: some(collectionDetails("V1", { size: 0 })),
  }).sendAndConfirm(umi);

  step("Creating regular NFT that references collection");
  await createNft(umi, {
    mint: nftMint,
    name: maybeEnv("NFT_NAME") || "Lecture 15 NFT #2",
    symbol: maybeEnv("NFT_SYMBOL") || "L15",
    uri: maybeEnv("NFT_URI") || "https://example.com/lecture-15-nft-2.json",
    sellerFeeBasisPoints: percentAmount(5),
    collection: { verified: false, key: collectionMint.publicKey },
  }).sendAndConfirm(umi);

  step("Verifying NFT inside collection");
  const nftMetadata = findMetadataPda(umi, { mint: publicKey(nftMint.publicKey) });
  await verifyCollectionV1(umi, {
    metadata: nftMetadata,
    collectionMint: publicKey(collectionMint.publicKey),
    authority: umi.identity,
  }).sendAndConfirm(umi);

  info("collection mint", collectionMint.publicKey);
  info("nft mint", nftMint.publicKey);
}

if (require.main === module) {
  runCollectionVerifyDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
