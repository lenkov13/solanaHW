import { generateSigner, none, percentAmount, publicKey, sol, some, transactionBuilder } from "@metaplex-foundation/umi";
import { collectionDetails, createNft } from "@metaplex-foundation/mpl-token-metadata";
import { addConfigLines, create, findCandyGuardPda } from "@metaplex-foundation/mpl-candy-machine";
import { makeConnection, loadOrCreatePayer, makeUmiWithPayer, info, section, step, maybeEnv } from "../helpers";

export async function runCandySetupDemo(): Promise<void> {
  section("Demo 3 — setup Candy Machine v3 with guards");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);
  const rpc = process.env.SOLANA_RPC?.trim() || "https://api.devnet.solana.com";
  const { umi } = makeUmiWithPayer(rpc, payer);

  const collectionMint = generateSigner(umi);
  const candyMachine = generateSigner(umi);

  const itemsAvailable = BigInt(Number(process.env.CANDY_ITEMS_AVAILABLE || "5"));
  step("Creating collection NFT for Candy Machine");
  await createNft(umi, {
    mint: collectionMint,
    name: maybeEnv("COLLECTION_NAME") || "Lecture 15 Candy Collection",
    symbol: maybeEnv("NFT_SYMBOL") || "L15",
    uri: maybeEnv("COLLECTION_URI") || "https://example.com/lecture-15-candy-collection.json",
    sellerFeeBasisPoints: percentAmount(5),
    isCollection: true,
    collectionDetails: some(collectionDetails("V1", { size: 0 })),
  }).sendAndConfirm(umi, { confirm: { commitment: "finalized" } });

  const guards = {
    startDate: some({ date: new Date(Date.now() - 5_000) }),
    mintLimit: some({ id: 1, limit: 2 }),
    solPayment: some({
      lamports: sol(0.05),
      destination: publicKey(umi.identity.publicKey),
    }),
    botTax: some({ lamports: sol(0.001), lastInstruction: true }),
  } as any;

  step("Creating Candy Machine");
  const builder = await create(umi as any, {
    candyMachine,
    collectionMint: collectionMint.publicKey,
    collectionUpdateAuthority: umi.identity,
    tokenStandard: 0,
    sellerFeeBasisPoints: percentAmount(5),
    itemsAvailable,
    creators: [{ address: umi.identity.publicKey, percentageShare: 100, verified: true }],
    isMutable: true,
    configLineSettings: some({
      prefixName: "L15 #",
      nameLength: 12,
      prefixUri: "https://example.com/l15/",
      uriLength: 16,
      isSequential: true,
    }),
    hiddenSettings: none(),
    guards: guards as any,
  } as any);
  await builder.sendAndConfirm(umi, { confirm: { commitment: "finalized" } });

  step("Inserting config lines");
  const totalItems = Number(itemsAvailable);
  const batchSize = 10;
  for (let offset = 0; offset < totalItems; offset += batchSize) {
    const chunk = Array.from({ length: Math.min(batchSize, totalItems - offset) }, (_, k) => {
      const i = offset + k;
      return { name: `${i + 1}`, uri: `${i + 1}.json` };
    });
    await transactionBuilder()
      .add(
        addConfigLines(umi, {
          candyMachine: candyMachine.publicKey,
          index: offset,
          configLines: chunk,
        }),
      )
      .sendAndConfirm(umi, { confirm: { commitment: "finalized" } });
  }
  info("config lines inserted", totalItems);

  const candyGuard = findCandyGuardPda(umi, { base: candyMachine.publicKey });

  info("candy machine", candyMachine.publicKey);
  info("candy guard", String(publicKey(candyGuard)));

  info("collection mint", collectionMint.publicKey);
}

if (require.main === module) {
  runCandySetupDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
