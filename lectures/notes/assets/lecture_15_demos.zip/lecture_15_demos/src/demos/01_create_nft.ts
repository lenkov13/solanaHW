import { generateSigner, percentAmount } from "@metaplex-foundation/umi";
import { createNft } from "@metaplex-foundation/mpl-token-metadata";
import { makeConnection, loadOrCreatePayer, makeUmiWithPayer, info, section, step, maybeEnv } from "../helpers";

export async function runCreateNftDemo(): Promise<void> {
  section("Demo 1 — create NFT via Metaplex Token Metadata");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);
  const rpc = process.env.SOLANA_RPC?.trim() || "https://api.devnet.solana.com";
  const { umi } = makeUmiWithPayer(rpc, payer);

  const mint = generateSigner(umi);
  const name = maybeEnv("NFT_NAME") || "Lecture 15 NFT #1";
  const symbol = maybeEnv("NFT_SYMBOL") || "L15";
  const uri = maybeEnv("NFT_URI") || "https://example.com/lecture-15-nft-1.json";

  step("Creating NFT");
  await createNft(umi, {
    mint,
    name,
    symbol,
    uri,
    sellerFeeBasisPoints: percentAmount(5),
  }).sendAndConfirm(umi);

  info("mint", mint.publicKey);
  info("name", name);
  info("uri", uri);
}

if (require.main === module) {
  runCreateNftDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
