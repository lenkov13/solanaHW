import { generateSigner, percentAmount } from "@metaplex-foundation/umi";
import {
  createProgrammableNft,
  fetchDigitalAsset,
  TokenStandard,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  info,
  loadOrCreatePayer,
  makeConnection,
  makeUmiWithPayer,
  maybeEnv,
  section,
  step,
} from "../helpers";

export async function runCreateProgrammableNftDemo(): Promise<void> {
  section("Demo 6 — create pNFT (ProgrammableNonFungible)");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);
  const rpc = process.env.SOLANA_RPC?.trim() || "https://api.devnet.solana.com";
  const { umi, signer } = makeUmiWithPayer(rpc, payer);

  const mint = generateSigner(umi);
  const name = maybeEnv("PNFT_NAME") || "Lecture pNFT #1";
  const symbol = maybeEnv("PNFT_SYMBOL") || "PNFT";
  const uri = maybeEnv("PNFT_URI") || "https://example.com/pnft.json";

  step("Creating programmable NFT");
  await createProgrammableNft(umi, {
    mint,
    authority: signer,
    payer: signer,
    updateAuthority: signer.publicKey,
    name,
    symbol,
    uri,
    sellerFeeBasisPoints: percentAmount(5),
  }).sendAndConfirm(umi);

  step("Reading metadata back");
  let asset: Awaited<ReturnType<typeof fetchDigitalAsset>> | null = null;
  let lastErr: unknown;
  const maxAttempts = 20;
  const retryDelayMs = 1500;
  for (let i = 0; i < maxAttempts; i++) {
    try {
      asset = await fetchDigitalAsset(umi, mint.publicKey);
      break;
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, retryDelayMs));
    }
  }
  if (!asset) throw lastErr;
  const tokenStandard = (asset.metadata.tokenStandard as any)?.__option === "Some"
    ? (asset.metadata.tokenStandard as any).value
    : "None";

  info("mint", mint.publicKey);
  info("token standard", tokenStandard);
  info(
    "is programmable",
    tokenStandard === TokenStandard.ProgrammableNonFungible ? "true" : "false",
  );
  info("name", asset.metadata.name);
  info("uri", asset.metadata.uri);
}

if (require.main === module) {
  runCreateProgrammableNftDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
