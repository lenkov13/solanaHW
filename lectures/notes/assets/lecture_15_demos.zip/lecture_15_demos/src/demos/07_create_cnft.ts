import { generateSigner } from "@metaplex-foundation/umi";
import {
  createTree,
  fetchTreeConfigFromSeeds,
  findLeafAssetIdPda,
  mintV1,
  mplBubblegum,
} from "@metaplex-foundation/mpl-bubblegum";
import {
  info,
  loadOrCreatePayer,
  makeConnection,
  makeUmiWithPayer,
  maybeEnv,
  section,
  step,
} from "../helpers";

async function waitForTreeInitialization(umi: any, merkleTree: any): Promise<void> {
  const maxAttempts = 20;
  const delayMs = 1500;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      await fetchTreeConfigFromSeeds(umi, { merkleTree });
      return;
    } catch (error) {
      if (attempt === maxAttempts) {
        throw new Error(`Merkle tree was not initialized in time: ${String(error)}`);
      }
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
}

export async function runCreateCompressedNftDemo(): Promise<void> {
  section("Demo 7 — create cNFT (Bubblegum)");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);
  const rpc = process.env.SOLANA_RPC?.trim() || "https://api.devnet.solana.com";
  const { umi, signer } = makeUmiWithPayer(rpc, payer);
  umi.use(mplBubblegum());

  const tree = generateSigner(umi);
  const name = maybeEnv("CNFT_NAME") || "Lecture cNFT #1";
  const symbol = maybeEnv("CNFT_SYMBOL") || "CNFT";
  const uri = maybeEnv("CNFT_URI") || "https://example.com/cnft.json";

  step("Creating Merkle tree for compressed NFTs");
  const createTreeTx = await createTree(umi, {
    merkleTree: tree,
    maxDepth: 14,
    maxBufferSize: 64,
    canopyDepth: 0,
    public: true,
  });
  await createTreeTx.sendAndConfirm(umi);
  await waitForTreeInitialization(umi, tree.publicKey);

  step("Minting one compressed NFT");
  await mintV1(umi, {
    leafOwner: signer.publicKey,
    leafDelegate: signer.publicKey,
    merkleTree: tree.publicKey,
    metadata: {
      name,
      symbol,
      uri,
      sellerFeeBasisPoints: 500,
      collection: null,
      creators: [{ address: signer.publicKey, verified: true, share: 100 }],
    },
  }).sendAndConfirm(umi);

  const treeConfig = await fetchTreeConfigFromSeeds(umi, {
    merkleTree: tree.publicKey,
  });
  const leafIndex = treeConfig.numMinted - 1n;
  const [assetId] = findLeafAssetIdPda(umi, {
    merkleTree: tree.publicKey,
    leafIndex,
  });

  info("merkle tree", tree.publicKey);
  info("tree num minted", treeConfig.numMinted.toString());
  info("latest leaf index", leafIndex.toString());
  info("derived asset id", assetId);
}

if (require.main === module) {
  runCreateCompressedNftDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
