import { generateSigner, publicKey, some, transactionBuilder } from "@metaplex-foundation/umi";
import { fetchCandyMachine, mintV2 } from "@metaplex-foundation/mpl-candy-machine";
import { setComputeUnitLimit } from "@metaplex-foundation/mpl-toolbox";
import { makeConnection, loadOrCreatePayer, makeUmiWithPayer, env, info, section, step } from "../helpers";

export async function runCandyMintDemo(): Promise<void> {
  section("Demo 4 — mint from Candy Machine");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);
  const rpc = process.env.SOLANA_RPC?.trim() || "https://api.devnet.solana.com";
  const { umi } = makeUmiWithPayer(rpc, payer);

  const candyMachinePk = publicKey(env("CANDY_MACHINE"));
  const candyGuardRaw = process.env.CANDY_GUARD?.trim();
  const candyGuardPk = candyGuardRaw ? publicKey(candyGuardRaw) : null;
  const collectionMintPk = publicKey(env("COLLECTION_MINT"));
  const nftMint = generateSigner(umi);

  step("Fetching candy machine");
  const cm = await fetchCandyMachine(umi, candyMachinePk);
  info("candy machine", cm.publicKey);

  step("Minting one NFT");
  const solPaymentDestination = publicKey(
    process.env.SOL_PAYMENT_DESTINATION?.trim() || umi.identity.publicKey,
  );
  const mintLimitId = Number(process.env.MINT_LIMIT_ID || "1");

  const mintInput: any = {
    candyMachine: candyMachinePk,
    nftMint: nftMint as any,
    collectionMint: collectionMintPk,
    collectionUpdateAuthority: umi.identity,
    mintArgs: {
      mintLimit: some({ id: mintLimitId }),
      solPayment: some({ destination: solPaymentDestination }),
    },
  };
  if (candyGuardPk) mintInput.candyGuard = candyGuardPk;
  await transactionBuilder()
    .add(setComputeUnitLimit(umi, { units: 800_000 }))
    .add(mintV2(umi, mintInput))
    .sendAndConfirm(umi);

  info("new nft mint", nftMint.publicKey);
}

if (require.main === module) {
  runCandyMintDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
