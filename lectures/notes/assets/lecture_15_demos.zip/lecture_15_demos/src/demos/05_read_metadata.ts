import { publicKey } from "@metaplex-foundation/umi";
import { fetchMetadataFromSeeds } from "@metaplex-foundation/mpl-token-metadata";
import { makeConnection, loadOrCreatePayer, makeUmiWithPayer, env, info, section, step } from "../helpers";

export async function runReadMetadataDemo(): Promise<void> {
  section("Demo 5 — read NFT metadata account");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);
  const rpc = process.env.SOLANA_RPC?.trim() || "https://api.devnet.solana.com";
  const { umi } = makeUmiWithPayer(rpc, payer);

  const mint = publicKey(env("NFT_MINT"));

  step("Fetching metadata PDA by mint");
  const metadata = (await fetchMetadataFromSeeds(umi, { mint })) as any;

  info("mint", metadata.mint);
  info("name", metadata.name);
  info("symbol", metadata.symbol);
  info("uri", metadata.uri);
  info("seller fee bps", metadata.sellerFeeBasisPoints);
  info("is mutable", metadata.isMutable ? "true" : "false");

  if (metadata.collection?.__option === "Some") {
    info("collection key", metadata.collection.value.key);
    info("collection verified", metadata.collection.value.verified ? "true" : "false");
  }

  if (metadata.creators?.__option === "Some" && metadata.creators.value.length) {
    for (const [i, c] of metadata.creators.value.entries()) {
      info(`creator[${i}]`, `${c.address} (${c.share}%) verified=${c.verified}`);
    }
  }
}

if (require.main === module) {
  runReadMetadataDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
