import * as fs from "fs";
import * as path from "path";
import { clusterApiUrl, Connection, Keypair, LAMPORTS_PER_SOL, PublicKey } from "@solana/web3.js";
import { createSignerFromKeypair, signerIdentity } from "@metaplex-foundation/umi";
import { createUmi } from "@metaplex-foundation/umi-bundle-defaults";
import { mplToolbox } from "@metaplex-foundation/mpl-toolbox";
import { mplTokenMetadata } from "@metaplex-foundation/mpl-token-metadata";
import { mplCandyMachine } from "@metaplex-foundation/mpl-candy-machine";
import { mplBubblegum } from "@metaplex-foundation/mpl-bubblegum";

const DLINE = "═".repeat(72);
const LINE = "─".repeat(72);

export function section(title: string): void {
  console.log("\n" + DLINE);
  console.log("  " + title);
  console.log(DLINE);
}

export function step(title: string): void {
  console.log("\n" + LINE);
  console.log("  " + title);
  console.log(LINE);
}

export function info(key: string, value: string | number | bigint): void {
  console.log(`  ${key.padEnd(24, " ")} ${value}`);
}

export function env(name: string, fallback?: string): string {
  const value = process.env[name]?.trim();
  if (value) return value;
  if (fallback !== undefined) return fallback;
  throw new Error(`Missing required env var: ${name}`);
}

export function maybeEnv(name: string): string | undefined {
  const v = process.env[name]?.trim();
  return v && v.length > 0 ? v : undefined;
}

export function makeConnection(): Connection {
  const endpoint = process.env.SOLANA_RPC?.trim() || clusterApiUrl("devnet");
  return new Connection(endpoint, "confirmed");
}

export function loadKeypair(pathToFile: string): Keypair {
  const raw = JSON.parse(fs.readFileSync(pathToFile, "utf8")) as number[];
  return Keypair.fromSecretKey(Uint8Array.from(raw));
}

export async function loadOrCreatePayer(conn: Connection): Promise<Keypair> {
  const envPath = process.env.WALLET_KEYPAIR?.trim();
  const defaultPath = path.join(__dirname, "..", "..", "..", "wallet-keypair.json");
  const candidate = envPath || defaultPath;

  if (fs.existsSync(candidate)) {
    const kp = loadKeypair(candidate);
    const bal = await conn.getBalance(kp.publicKey);
    info("payer", kp.publicKey.toBase58());
    info("payer balance", `${(bal / LAMPORTS_PER_SOL).toFixed(4)} SOL`);
    if (bal < 0.2 * LAMPORTS_PER_SOL) {
      await requestAirdrop(conn, kp.publicKey, 1);
    }
    return kp;
  }

  const kp = Keypair.generate();
  info("generated payer", kp.publicKey.toBase58());
  await requestAirdrop(conn, kp.publicKey, 2);
  return kp;
}

export async function requestAirdrop(conn: Connection, pubkey: PublicKey, sol: number): Promise<void> {
  if (process.env.SOLANA_RPC && !process.env.SOLANA_RPC.includes("devnet")) {
    return;
  }
  try {
    const sig = await conn.requestAirdrop(pubkey, sol * LAMPORTS_PER_SOL);
    const latest = await conn.getLatestBlockhash("confirmed");
    await conn.confirmTransaction(
      { signature: sig, blockhash: latest.blockhash, lastValidBlockHeight: latest.lastValidBlockHeight },
      "confirmed",
    );
    info("airdrop", `+${sol} SOL`);
  } catch (e) {
    info("airdrop warning", String(e));
  }
}

export function makeUmiWithPayer(rpc: string, payer: Keypair) {
  const umi = createUmi(rpc);
  umi.use(mplToolbox());
  umi.use(mplTokenMetadata());
  umi.use(mplCandyMachine());
  umi.use(mplBubblegum());
  const umiKeypair = umi.eddsa.createKeypairFromSecretKey(payer.secretKey);
  const signer = createSignerFromKeypair(umi, umiKeypair);
  umi.use(signerIdentity(signer));
  return { umi, signer };
}
