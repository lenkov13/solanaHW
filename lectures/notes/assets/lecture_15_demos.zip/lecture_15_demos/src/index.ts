import { runCreateNftDemo } from "./demos/01_create_nft";
import { runCollectionVerifyDemo } from "./demos/02_collection_and_verify";
import { runCandySetupDemo } from "./demos/03_candy_machine_setup";
import { runReadMetadataDemo } from "./demos/05_read_metadata";

async function main(): Promise<void> {
  await runCreateNftDemo();
  await runCollectionVerifyDemo();
  await runCandySetupDemo();

  console.log("\nSet NFT_MINT env var and run demo:5 to inspect metadata.");
  console.log("Set CANDY_MACHINE/COLLECTION_MINT (and optional CANDY_GUARD) then run demo:4 to mint from Candy Machine.");

  if (process.env.NFT_MINT) {
    await runReadMetadataDemo();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
