import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = { children: ReactNode };
type State = { err: Error | null };

export class ErrorBoundary extends Component<Props, State> {
  state: State = { err: null };

  static getDerivedStateFromError(err: Error): State {
    return { err };
  }

  componentDidCatch(err: Error, info: ErrorInfo) {
    console.error("UI error:", err, info.componentStack);
  }

  render() {
    if (this.state.err) {
      return (
        <div
          style={{
            fontFamily: "ui-monospace, monospace",
            padding: 24,
            maxWidth: 640,
            margin: "0 auto",
            color: "#e6edf3",
            background: "#0d1117",
            minHeight: "100vh",
          }}
        >
          <h1 style={{ fontSize: 18, marginTop: 0 }}>App crashed</h1>
          <p style={{ color: "#8b949e" }}>
            Open the browser devtools console (F12) for the full stack.
          </p>
          <pre
            style={{
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              background: "#161b22",
              padding: 12,
              borderRadius: 8,
              fontSize: 12,
            }}
          >
            {this.state.err.message}
            {"\n\n"}
            {this.state.err.stack}
          </pre>
        </div>
      );
    }
    return this.props.children;
  }
}
