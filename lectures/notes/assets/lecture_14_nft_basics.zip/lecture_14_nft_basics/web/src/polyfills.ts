
import { Buffer } from "buffer";

const g = globalThis as typeof globalThis & {
  Buffer: typeof Buffer;
  global: typeof globalThis;
  process?: { env: Record<string, string | boolean | undefined> };
};

g.Buffer = Buffer;
g.global = g;
if (typeof (g as { process?: unknown }).process === "undefined") {
  (g as { process: { env: Record<string, string | boolean | undefined> } }).process =
    {
      env: {
        ...((import.meta.env as unknown) as Record<string, string | boolean | undefined>),
        NODE_ENV: import.meta.env.DEV ? "development" : "production",
      },
    };
}
