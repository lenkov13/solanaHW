import type { Dispatch, SetStateAction } from "react";
import { PublicKey } from "@solana/web3.js";

const LINE = "─".repeat(72);
const DLINE = "═".repeat(72);

export type LogLines = string[];
export type AppendLog = (line: string) => void;

export function makeAppendLog(
  setLines: Dispatch<SetStateAction<string[]>>,
): AppendLog {
  return (line) => {
    setLines((prev) => [...prev, line]);
  };
}

export function sectionOut(out: (s: string) => void, title: string) {
  out("\n" + DLINE);
  out("  " + title);
  out(DLINE);
}

export function stepOut(out: (s: string) => void, title: string) {
  out("\n" + LINE);
  out("  " + title);
  out(LINE);
}

export function infoOut(
  out: (s: string) => void,
  k: string,
  v: string | number | bigint,
) {
  const pad = k.padEnd(22, " ");
  out(`  ${pad} ${v}`);
}

export function shortPk(pk: PublicKey): string {
  const s = pk.toBase58();
  return `${s.slice(0, 4)}…${s.slice(-4)}`;
}

export function fmtAmount(raw: bigint, decimals: number): string {
  const d = BigInt(decimals);
  const base = 10n ** d;
  const whole = raw / base;
  const frac = (raw % base)
    .toString()
    .padStart(decimals, "0")
    .replace(/0+$/, "");
  return frac ? `${whole}.${frac}` : whole.toString();
}
