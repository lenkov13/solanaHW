export function getMetadataBaseUri(): string {
  const override = import.meta.env.VITE_LECTURE_14_BASE_URI?.trim().replace(
    /\/$/,
    "",
  );
  if (override) return override;
  if (typeof window !== "undefined") {
    return `${window.location.origin}/lecture-14`;
  }
  return "http://localhost:5173/lecture-14";
}

export const LECTURE_14_BASE_URI = getMetadataBaseUri();
