import {
  Connection,
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
  TransactionMessage,
  TransactionSignature,
  VersionedTransaction,
} from "@solana/web3.js";
import { WalletContextState } from "@solana/wallet-adapter-react";

export type SendTransactionFn = WalletContextState["sendTransaction"];

function formatSendFailure(e: unknown): string {
  if (e == null) return "Unknown error";
  if (typeof e !== "object") return String(e);
  const w = e as {
    message?: string;
    name?: string;
    error?: { message?: string; code?: number; data?: unknown };
  };
  const parts: string[] = [];
  if (w.name) parts.push(w.name);
  if (w.message) parts.push(w.message);
  const inner = w.error;
  if (inner && typeof inner === "object") {
    if ("message" in inner && inner.message) parts.push(String(inner.message));
    if ("code" in inner && inner.code != null) parts.push(`code=${String(inner.code)}`);
  }
  const text = parts.filter(Boolean).join(" | ");
  return text || String(e);
}

export async function sendWithWallet(
  connection: Connection,
  wallet: WalletContextState,
  tx: Transaction,
  otherSigners: Keypair[] = [],
): Promise<TransactionSignature> {
  if (!wallet.sendTransaction) throw new Error("Wallet has no sendTransaction");
  if (!wallet.publicKey) throw new Error("Connect wallet first");

  const { blockhash, lastValidBlockHeight } =
    await connection.getLatestBlockhash("confirmed");
  tx.feePayer = wallet.publicKey;
  tx.recentBlockhash = blockhash;

  const forSim = new VersionedTransaction(
    new TransactionMessage({
      payerKey: wallet.publicKey,
      recentBlockhash: blockhash,
      instructions: tx.instructions,
    }).compileToV0Message(),
  );
  if (otherSigners.length > 0) {
    forSim.sign(otherSigners);
  }

  try {
    const sim = await connection.simulateTransaction(forSim, {

      sigVerify: false,
    });
    if (sim.value.err) {
      const logs = sim.value.logs ?? [];
      throw new Error(
        `Simulation failed: ${JSON.stringify(sim.value.err)}` +
          (logs.length
            ? `\n\nProgram logs:\n${logs.join("\n")}`
            : "\n(no program logs)"),
      );
    }
  } catch (e) {
    if (e instanceof Error && e.message.startsWith("Simulation failed")) {
      throw e;
    }
    if (import.meta.env.DEV) {
      console.warn(
        "[sendWithWallet] simulateTransaction warning (send will still be attempted):",
        e,
      );
    }
  }

  let signature: TransactionSignature;
  try {
    signature = await wallet.sendTransaction(
      tx,
      connection,
      otherSigners.length > 0 ? { signers: otherSigners } : undefined,
    );
  } catch (e) {
    throw new Error(
      `Wallet / RPC send: ${formatSendFailure(e)}` +
        (e && typeof e === "object" && "error" in (e as object)
          ? `\n[inner] ${String((e as { error: unknown }).error)}`
          : "") +
        `\n(Tip: ensure devnet, enough SOL, and the wallet network matches the app RPC.)`,
    );
  }

  const latest = { blockhash, lastValidBlockHeight };
  await connection.confirmTransaction(
    { signature, ...latest },
    "confirmed",
  );
  return signature;
}

export async function fundLamports(
  connection: Connection,
  wallet: WalletContextState,
  to: PublicKey,
  lamports: number,
): Promise<void> {
  const from = wallet.publicKey;
  if (!from) throw new Error("Connect wallet");
  const tx = new Transaction().add(
    SystemProgram.transfer({ fromPubkey: from, toPubkey: to, lamports }),
  );
  await sendWithWallet(connection, wallet, tx, []);
}
