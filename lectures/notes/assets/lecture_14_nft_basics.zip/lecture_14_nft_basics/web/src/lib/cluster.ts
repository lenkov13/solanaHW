import { clusterApiUrl, Cluster } from "@solana/web3.js";

export function parseCluster(): Cluster {
  const c = (import.meta.env.VITE_SOLANA_CLUSTER || "devnet").toLowerCase();
  if (c === "mainnet" || c === "mainnet-beta")
    return "mainnet-beta";
  if (c === "testnet") return "testnet";
  return "devnet";
}

export function getClusterEndpoint(cluster: Cluster): string {
  return clusterApiUrl(cluster);
}
