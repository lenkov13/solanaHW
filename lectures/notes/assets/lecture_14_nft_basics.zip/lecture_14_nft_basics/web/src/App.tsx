import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { LAMPORTS_PER_SOL } from "@solana/web3.js";
import { useState } from "react";
import { SplNftTab } from "./tabs/SplNftTab";
import { Token2022NftTab } from "./tabs/Token2022NftTab";
import { MetaplexNftTab } from "./tabs/MetaplexNftTab";
import { PrintEditionTab } from "./tabs/PrintEditionTab";
import { ReadNftTab } from "./tabs/ReadNftTab";
import { CollectionNftTab } from "./tabs/CollectionNftTab";

const TABS = [
  { id: "spl", label: "1 — SPL classic NFT" },
  { id: "t22", label: "2 — Token-2022 NFT" },
  { id: "mpl", label: "3 — Metaplex metadata" },
  { id: "print", label: "4 — Print editions" },
  { id: "read", label: "5 — Read & validate" },
  { id: "coll", label: "6 — Collection + verify" },
] as const;

export default function App({
  clusterLabel,
  defaultRpc,
}: {
  clusterLabel: string;
  defaultRpc: string;
}) {
  const [tab, setTab] = useState(0);
  const { connection } = useConnection();
  const { publicKey } = useWallet();
  const [airdropMsg, setAirdropMsg] = useState<string | null>(null);
  const isDevnet = clusterLabel === "devnet";

  async function requestAirdrop() {
    if (!publicKey) {
      setAirdropMsg("Connect wallet first.");
      return;
    }
    if (!isDevnet) {
      setAirdropMsg("Airdrop only on devnet.");
      return;
    }
    setAirdropMsg(null);
    try {
      const { blockhash, lastValidBlockHeight } =
        await connection.getLatestBlockhash("confirmed");
      const sig = await connection.requestAirdrop(
        publicKey,
        1 * LAMPORTS_PER_SOL,
      );
      await connection.confirmTransaction(
        { signature: sig, blockhash, lastValidBlockHeight },
        "confirmed",
      );
      setAirdropMsg(`Airdrop ok: ${sig.slice(0, 8)}…`);
    } catch (e) {
      setAirdropMsg(String(e));
    }
  }

  return (
    <div className="app">
      <header className="header">
        <div>
          <h1>Lecture 14 — NFT basics</h1>
          <p className="sub">
            Cluster: <code>{clusterLabel}</code> · RPC:{" "}
            <code className="rpc">{defaultRpc}</code>
          </p>
        </div>
        <div className="headerActions">
          {isDevnet && (
            <button
              type="button"
              className="airdropBtn"
              onClick={requestAirdrop}
            >
              Airdrop 1 SOL (devnet)
            </button>
          )}
          <WalletMultiButton />
        </div>
      </header>
      {airdropMsg && <p className="airdropMsg">{airdropMsg}</p>}

      <nav className="tabs" role="tablist" aria-label="Demos">
        {TABS.map((t, i) => (
          <button
            key={t.id}
            type="button"
            role="tab"
            aria-selected={tab === i}
            className={tab === i ? "tab active" : "tab"}
            onClick={() => setTab(i)}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <main className="main">
        {tab === 0 && <SplNftTab />}
        {tab === 1 && <Token2022NftTab />}
        {tab === 2 && <MetaplexNftTab />}
        {tab === 3 && <PrintEditionTab />}
        {tab === 4 && <ReadNftTab clusterLabel={clusterLabel} />}
        {tab === 5 && <CollectionNftTab />}
      </main>
    </div>
  );
}
