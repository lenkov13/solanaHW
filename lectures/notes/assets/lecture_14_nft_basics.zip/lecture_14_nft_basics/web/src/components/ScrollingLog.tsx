import { useEffect, useRef } from "react";

export function ScrollingLog({
  lines,
  emptyPlaceholder,
  label = "output",
}: {
  lines: string[];
  emptyPlaceholder: string;
  label?: string;
}) {
  const preRef = useRef<HTMLPreElement>(null);

  useEffect(() => {
    const el = preRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [lines]);

  return (
    <pre className="log" ref={preRef} aria-label={label}>
      {lines.length > 0 ? lines.join("\n") : emptyPlaceholder}
    </pre>
  );
}
