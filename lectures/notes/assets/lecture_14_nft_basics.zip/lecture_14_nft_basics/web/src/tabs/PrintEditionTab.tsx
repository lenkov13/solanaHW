import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { useState } from "react";
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  getAssociatedTokenAddressSync,
  getMint,
  getMinimumBalanceForRentExemptMint,
} from "@solana/spl-token";
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Edition,
  MasterEditionV2,
  createCreateMasterEditionV3Instruction,
  createCreateMetadataAccountV3Instruction,
  createMintNewEditionFromMasterEditionViaTokenInstruction,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";
import { ScrollingLog } from "../components/ScrollingLog";
import { sendWithWallet } from "../lib/sendWallet";
import { LECTURE_14_BASE_URI } from "../lib/metadata";
import {
  infoOut,
  makeAppendLog,
  sectionOut,
  shortPk,
  stepOut,
} from "../lib/logFormat";

const SERIES_MAX_SUPPLY = 3;
const PRINTS_TO_MINT = 2;

function findMetadataPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findEditionMarkerPda(masterMint: PublicKey, edition: bigint): PublicKey {
  const page = (edition / 248n).toString();
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      masterMint.toBuffer(),
      Buffer.from("edition"),
      Buffer.from(page),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

export function PrintEditionTab() {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [lines, setLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    if (!wallet.publicKey) {
      setLines(["Connect Phantom first."]);
      return;
    }
    setRunning(true);
    setLines([]);
    const log = makeAppendLog(setLines);
    const wb = wallet;
    const owner = wb.publicKey!;

    try {
      sectionOut(log, "Demo 4 — Print Editions (numbered series)");

      const masterKp = Keypair.generate();
      const masterMint = masterKp.publicKey;
      const masterAta = getAssociatedTokenAddressSync(
        masterMint,
        owner,
        false,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID,
      );
      const masterMetadataPda = findMetadataPda(masterMint);
      const masterEditionPda = findEditionPda(masterMint);

      stepOut(
        log,
        `1. готовим series master (maxSupply = ${SERIES_MAX_SUPPLY}) — confirm in wallet`,
      );
      infoOut(log, "master mint", masterMint.toBase58());
      infoOut(log, "master metadata PDA", masterMetadataPda.toBase58());
      infoOut(log, "master edition PDA", masterEditionPda.toBase58());

      const mintRent = await getMinimumBalanceForRentExemptMint(connection);
      const tx0 = new Transaction().add(
        SystemProgram.createAccount({
          fromPubkey: owner,
          newAccountPubkey: masterMint,
          space: MINT_SIZE,
          lamports: mintRent,
          programId: TOKEN_PROGRAM_ID,
        }),
        createInitializeMint2Instruction(
          masterMint,
          0,
          owner,
          owner,
          TOKEN_PROGRAM_ID,
        ),
        createAssociatedTokenAccountInstruction(
          owner,
          masterAta,
          owner,
          masterMint,
          TOKEN_PROGRAM_ID,
          ASSOCIATED_TOKEN_PROGRAM_ID,
        ),
        createMintToInstruction(
          masterMint,
          masterAta,
          owner,
          1n,
          [],
          TOKEN_PROGRAM_ID,
        ),
        createCreateMetadataAccountV3Instruction(
          {
            metadata: masterMetadataPda,
            mint: masterMint,
            mintAuthority: owner,
            payer: owner,
            updateAuthority: owner,
          },
          {
            createMetadataAccountArgsV3: {
              data: {
                name: "Course Series — L14",
                symbol: "CRSER",
                uri: `${LECTURE_14_BASE_URI}/04_print_series.json`,
                sellerFeeBasisPoints: 500,
                creators: [{ address: owner, verified: true, share: 100 }],
                collection: null,
                uses: null,
              },
              isMutable: true,
              collectionDetails: null,
            },
          },
        ),
        createCreateMasterEditionV3Instruction(
          {
            edition: masterEditionPda,
            mint: masterMint,
            updateAuthority: owner,
            mintAuthority: owner,
            payer: owner,
            metadata: masterMetadataPda,
          },
          {
            createMasterEditionArgs: { maxSupply: SERIES_MAX_SUPPLY },
          },
        ),
      );
      await sendWithWallet(connection, wb, tx0, [masterKp]);

      const prints: Array<{ mint: PublicKey; edition: bigint }> = [];

      for (let n = 1n; n <= BigInt(PRINTS_TO_MINT); n++) {
        stepOut(
          log,
          `2.${n}. печатаем edition #${n} из ${SERIES_MAX_SUPPLY} — confirm in wallet`,
        );

        const newMintKp = Keypair.generate();
        const newMint = newMintKp.publicKey;
        const newAta = getAssociatedTokenAddressSync(
          newMint,
          owner,
          false,
          TOKEN_PROGRAM_ID,
          ASSOCIATED_TOKEN_PROGRAM_ID,
        );
        const newMetadataPda = findMetadataPda(newMint);
        const newEditionPda = findEditionPda(newMint);
        const editionMarkerPda = findEditionMarkerPda(masterMint, n);

        infoOut(log, "new mint", newMint.toBase58());
        infoOut(log, "editionMarker PDA", editionMarkerPda.toBase58());

        const txPrint = new Transaction().add(

          SystemProgram.createAccount({
            fromPubkey: owner,
            newAccountPubkey: newMint,
            space: MINT_SIZE,
            lamports: mintRent,
            programId: TOKEN_PROGRAM_ID,
          }),
          createInitializeMint2Instruction(
            newMint,
            0,
            owner,
            owner,
            TOKEN_PROGRAM_ID,
          ),
          createAssociatedTokenAccountInstruction(
            owner,
            newAta,
            owner,
            newMint,
            TOKEN_PROGRAM_ID,
            ASSOCIATED_TOKEN_PROGRAM_ID,
          ),
          createMintToInstruction(
            newMint,
            newAta,
            owner,
            1n,
            [],
            TOKEN_PROGRAM_ID,
          ),

          createMintNewEditionFromMasterEditionViaTokenInstruction(
            {
              newMetadata: newMetadataPda,
              newEdition: newEditionPda,
              masterEdition: masterEditionPda,
              newMint,
              editionMarkPda: editionMarkerPda,
              newMintAuthority: owner,
              payer: owner,
              tokenAccountOwner: owner,
              tokenAccount: masterAta,
              newMetadataUpdateAuthority: owner,
              metadata: masterMetadataPda,
            },
            {
              mintNewEditionFromMasterEditionViaTokenArgs: { edition: n },
            },
          ),
        );

        await sendWithWallet(connection, wb, txPrint, [newMintKp]);
        prints.push({ mint: newMint, edition: n });
      }

      stepOut(
        log,
        `3. читаем master edition (supply должен быть = ${PRINTS_TO_MINT})`,
      );
      const masterAcc = await connection.getAccountInfo(
        masterEditionPda,
        "confirmed",
      );
      if (!masterAcc) throw new Error("master edition not found");
      const [masterEdition] = MasterEditionV2.deserialize(masterAcc.data);
      infoOut(log, "master.supply", String(masterEdition.supply));
      infoOut(
        log,
        "master.maxSupply",
        String(masterEdition.maxSupply ?? "null"),
      );
      infoOut(log, "master.key", String(masterEdition.key));

      stepOut(log, "4. читаем каждый Print: parent + номер");
      for (const { mint: copyMint, edition: n } of prints) {
        const editionAcc = await connection.getAccountInfo(
          findEditionPda(copyMint),
          "confirmed",
        );
        if (!editionAcc) throw new Error(`edition #${n} account not found`);
        const [edition] = Edition.deserialize(editionAcc.data);
        infoOut(
          log,
          `print #${n}`,
          `mint=${shortPk(copyMint)}, parent=${shortPk(
            new PublicKey(edition.parent),
          )}, edition=${String(edition.edition)}, key=${String(edition.key)}`,
        );

        const copyMintInfo = await getMint(
          connection,
          copyMint,
          "confirmed",
          TOKEN_PROGRAM_ID,
        );
        infoOut(
          log,
          `print #${n} mint`,
          `decimals=${copyMintInfo.decimals}, supply=${String(
            copyMintInfo.supply,
          )}, mintAuthority=${
            copyMintInfo.mintAuthority?.toBase58() ?? "null"
          }`,
        );
      }

      log(
        "\n  Итог: одна транзакция Print Edition создаёт целый «мини-NFT» — новый mint, новую Metadata (с копией name/symbol/uri),",
      );
      log(
        "       новый Edition PDA (key = EditionV1) и обновляет битовую карту editionMarker. Supply на Master инкрементится автоматически.",
      );
      log(
        `       Когда supply == maxSupply (${SERIES_MAX_SUPPLY}), программа Metaplex отказывает в дальнейших печатях.`,
      );
    } catch (e) {
      log(String(e));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="tabBody">
      <p className="lede">
        Как <code>04_print_edition.ts</code>: создаём series-master c{" "}
        <code>maxSupply = {SERIES_MAX_SUPPLY}</code>, затем печатаем{" "}
        {PRINTS_TO_MINT} копий через{" "}
        <code>MintNewEditionFromMasterEditionViaToken</code>. Phantom попросит
        подпись на каждую транзакцию (1 master + {PRINTS_TO_MINT} prints).
      </p>
      <div className="row">
        <button type="button" disabled={running} onClick={run}>
          {running ? "Running…" : "Run demo 4"}
        </button>
      </div>
      <ScrollingLog
        lines={lines}
        emptyPlaceholder="Output updates after each wallet step (same as console)."
      />
    </div>
  );
}
