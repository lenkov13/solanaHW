import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { useState } from "react";
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  getAssociatedTokenAddressSync,
  getMint,
  getMinimumBalanceForRentExemptMint,
} from "@solana/spl-token";
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Metadata,
  createCreateMasterEditionV3Instruction,
  createCreateMetadataAccountV3Instruction,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  ComputeBudgetProgram,
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";
import { ScrollingLog } from "../components/ScrollingLog";
import { sendWithWallet } from "../lib/sendWallet";
import { LECTURE_14_BASE_URI } from "../lib/metadata";
import {
  infoOut,
  makeAppendLog,
  sectionOut,
  shortPk,
  stepOut,
} from "../lib/logFormat";

function findMetadataPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findMasterEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

export function MetaplexNftTab() {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [lines, setLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    if (!wallet.publicKey) {
      setLines(["Connect Phantom first."]);
      return;
    }
    setRunning(true);
    setLines([]);
    const log = makeAppendLog(setLines);
    const wb = wallet;
    const owner = wb.publicKey!;
    try {
      sectionOut(log, "Demo 3 — Metaplex Token Metadata (low-level)");

      const mintKp = Keypair.generate();
      const mint = mintKp.publicKey;
      const ata = getAssociatedTokenAddressSync(
        mint,
        owner,
        false,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID,
      );
      const metadataPda = findMetadataPda(mint);
      const editionPda = findMasterEditionPda(mint);

      stepOut(log, "1. адреса (PDA выводятся детерминированно из mint)");
      infoOut(log, "token metadata program", TOKEN_METADATA_PROGRAM_ID.toBase58());
      infoOut(log, "mint", mint.toBase58());
      infoOut(log, "ata", shortPk(ata));
      infoOut(log, "metadata PDA", metadataPda.toBase58());
      infoOut(log, "masterEdition PDA", editionPda.toBase58());

      stepOut(
        log,
        "2. tx #1 — обычный SPL: createAccount + initMint2(0) + ATA + mintTo(1) — confirm in wallet",
      );
      const mintRent = await getMinimumBalanceForRentExemptMint(connection);
      const tx1 = new Transaction().add(
        SystemProgram.createAccount({
          fromPubkey: owner,
          newAccountPubkey: mint,
          space: MINT_SIZE,
          lamports: mintRent,
          programId: TOKEN_PROGRAM_ID,
        }),

        createInitializeMint2Instruction(
          mint,
          0,
          owner,
          owner,
          TOKEN_PROGRAM_ID,
        ),
        createAssociatedTokenAccountInstruction(
          owner,
          ata,
          owner,
          mint,
          TOKEN_PROGRAM_ID,
          ASSOCIATED_TOKEN_PROGRAM_ID,
        ),
        createMintToInstruction(
          mint,
          ata,
          owner,
          1n,
          [],
          TOKEN_PROGRAM_ID,
        ),
      );
      await sendWithWallet(connection, wb, tx1, [mintKp]);

      stepOut(
        log,
        "3. tx #2 — CreateMetadataAccountV3 — пишем DataV2 в metadata-PDA — confirm in wallet",
      );
      const tx2 = new Transaction()
        .add(ComputeBudgetProgram.setComputeUnitLimit({ units: 400_000 }))
        .add(
          createCreateMetadataAccountV3Instruction(
            {
              metadata: metadataPda,
              mint,
              mintAuthority: owner,
              payer: owner,
              updateAuthority: owner,
            },
            {
              createMetadataAccountArgsV3: {
                data: {
                  name: "Course NFT — L14 (low-level)",
                  symbol: "CRSLOW",
                  uri: `${LECTURE_14_BASE_URI}/03_metaplex.json`,
                  sellerFeeBasisPoints: 500,
                  creators: [
                    { address: owner, verified: true, share: 100 },
                  ],
                  collection: null,
                  uses: null,
                },
                isMutable: true,
                collectionDetails: null,
              },
            },
          ),
        );
      await sendWithWallet(connection, wb, tx2, []);

      stepOut(
        log,
        "4. tx #3 — CreateMasterEditionV3 (maxSupply=0) — фиксируем supply=1 и переносим mintAuthority на edition PDA — confirm in wallet",
      );
      const tx3 = new Transaction().add(
        createCreateMasterEditionV3Instruction(
          {
            edition: editionPda,
            mint,
            updateAuthority: owner,
            mintAuthority: owner,
            payer: owner,
            metadata: metadataPda,
          },
          {
            createMasterEditionArgs: { maxSupply: 0 },
          },
        ),
      );
      await sendWithWallet(connection, wb, tx3, []);

      stepOut(log, "5. читаем mint и metadata напрямую (без SDK)");
      const mintInfo = await getMint(
        connection,
        mint,
        "confirmed",
        TOKEN_PROGRAM_ID,
      );
      infoOut(log, "decimals", mintInfo.decimals);
      infoOut(log, "supply", mintInfo.supply.toString());
      infoOut(
        log,
        "mintAuthority",
        mintInfo.mintAuthority?.toBase58() ?? "null",
      );
      infoOut(
        log,
        "freezeAuthority",
        mintInfo.freezeAuthority?.toBase58() ?? "null",
      );

      const metaAcc = await connection.getAccountInfo(
        metadataPda,
        "confirmed",
      );
      if (!metaAcc) throw new Error("metadata account not found");
      const [meta] = Metadata.deserialize(metaAcc.data);
      infoOut(log, "name", meta.data.name.replace(/\u0000/g, ""));
      infoOut(log, "symbol", meta.data.symbol.replace(/\u0000/g, ""));
      infoOut(log, "uri", meta.data.uri.replace(/\u0000/g, ""));
      infoOut(log, "seller fee bps", meta.data.sellerFeeBasisPoints);
      infoOut(log, "update authority", meta.updateAuthority.toBase58());
      infoOut(log, "is mutable", String(meta.isMutable));

      log(
        "\n  Итог: Metaplex Token Metadata = одна программа + два PDA + две инструкции.",
      );
      log(
        "       Master Edition держит mintAuthority и freezeAuthority программы — именно так supply навсегда фиксируется в 1.",
      );
    } catch (e) {
      log(String(e));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="tabBody">
      <p className="lede">
        Как <code>03_metaplex_metadata.ts</code>: три транзакции вручную через
        web3.js — стандартный SPL mint(1), затем{" "}
        <code>CreateMetadataAccountV3</code> и{" "}
        <code>CreateMasterEditionV3(maxSupply=0)</code>. Никакого Umi.
      </p>
      <div className="row">
        <button type="button" disabled={running} onClick={run}>
          {running ? "Running…" : "Run demo 3"}
        </button>
      </div>
      <ScrollingLog
        lines={lines}
        emptyPlaceholder="Output updates after each wallet step (same as console)."
      />
    </div>
  );
}
