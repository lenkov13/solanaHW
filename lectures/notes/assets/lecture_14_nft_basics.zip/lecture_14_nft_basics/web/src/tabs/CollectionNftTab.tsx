import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { useState } from "react";
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  getAssociatedTokenAddressSync,
  getMinimumBalanceForRentExemptMint,
} from "@solana/spl-token";
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Metadata,
  createCreateMasterEditionV3Instruction,
  createCreateMetadataAccountV3Instruction,
  createVerifySizedCollectionItemInstruction,
  isCollectionDetailsV1,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  Connection,
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";
import { WalletContextState } from "@solana/wallet-adapter-react";
import { ScrollingLog } from "../components/ScrollingLog";
import { sendWithWallet } from "../lib/sendWallet";
import { LECTURE_14_BASE_URI } from "../lib/metadata";
import {
  infoOut,
  makeAppendLog,
  sectionOut,
  shortPk,
  stepOut,
} from "../lib/logFormat";

function findMetadataPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

interface NftCreated {
  mint: PublicKey;
  metadataPda: PublicKey;
  editionPda: PublicKey;
}

async function createMasterEditionNft(
  conn: Connection,
  wallet: WalletContextState,
  owner: PublicKey,
  opts: {
    name: string;
    symbol: string;
    uri: string;
    collection: { key: PublicKey; verified: boolean } | null;
    collectionDetails: { __kind: "V1"; size: number } | null;
  },
): Promise<NftCreated> {
  const mintKp = Keypair.generate();
  const mint = mintKp.publicKey;
  const ata = getAssociatedTokenAddressSync(
    mint,
    owner,
    false,
    TOKEN_PROGRAM_ID,
    ASSOCIATED_TOKEN_PROGRAM_ID,
  );
  const metadataPda = findMetadataPda(mint);
  const editionPda = findEditionPda(mint);

  const mintRent = await getMinimumBalanceForRentExemptMint(conn);
  const tx = new Transaction().add(
    SystemProgram.createAccount({
      fromPubkey: owner,
      newAccountPubkey: mint,
      space: MINT_SIZE,
      lamports: mintRent,
      programId: TOKEN_PROGRAM_ID,
    }),
    createInitializeMint2Instruction(mint, 0, owner, owner, TOKEN_PROGRAM_ID),
    createAssociatedTokenAccountInstruction(
      owner,
      ata,
      owner,
      mint,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID,
    ),
    createMintToInstruction(mint, ata, owner, 1n, [], TOKEN_PROGRAM_ID),
    createCreateMetadataAccountV3Instruction(
      {
        metadata: metadataPda,
        mint,
        mintAuthority: owner,
        payer: owner,
        updateAuthority: owner,
      },
      {
        createMetadataAccountArgsV3: {
          data: {
            name: opts.name,
            symbol: opts.symbol,
            uri: opts.uri,
            sellerFeeBasisPoints: 500,
            creators: [{ address: owner, verified: true, share: 100 }],
            collection: opts.collection,
            uses: null,
          },
          isMutable: true,
          collectionDetails: opts.collectionDetails,
        },
      },
    ),
    createCreateMasterEditionV3Instruction(
      {
        edition: editionPda,
        mint,
        updateAuthority: owner,
        mintAuthority: owner,
        payer: owner,
        metadata: metadataPda,
      },
      { createMasterEditionArgs: { maxSupply: 0 } },
    ),
  );

  await sendWithWallet(conn, wallet, tx, [mintKp]);
  return { mint, metadataPda, editionPda };
}

export function CollectionNftTab() {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [lines, setLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    if (!wallet.publicKey) {
      setLines(["Connect Phantom first."]);
      return;
    }
    setRunning(true);
    setLines([]);
    const log = makeAppendLog(setLines);
    const owner = wallet.publicKey!;

    try {
      sectionOut(log, "Demo 6 — Collection NFT + verified members");
      stepOut(log, "0. URIs (off-chain JSON в web/public/lecture-14/)");
      infoOut(log, "collection.uri", `${LECTURE_14_BASE_URI}/collection.json`);
      infoOut(log, "nft_1.uri", `${LECTURE_14_BASE_URI}/nft_1.json`);
      infoOut(log, "nft_2.uri", `${LECTURE_14_BASE_URI}/nft_2.json`);

      stepOut(
        log,
        "1. tx#1 — COLLECTION NFT (Master Edition + collectionDetails.V1.size=0) — confirm in wallet",
      );
      const collection = await createMasterEditionNft(
        connection,
        wallet,
        owner,
        {
          name: "Course Collection — L14",
          symbol: "CRSCOL",
          uri: `${LECTURE_14_BASE_URI}/collection.json`,
          collection: null,
          collectionDetails: { __kind: "V1", size: 0 },
        },
      );
      infoOut(log, "collection mint", collection.mint.toBase58());
      infoOut(log, "collection metadata PDA", shortPk(collection.metadataPda));
      infoOut(log, "collection edition PDA", shortPk(collection.editionPda));

      stepOut(
        log,
        "2. tx#2 — NFT #1 с collection={ key, verified=false } — confirm in wallet",
      );
      const nft1 = await createMasterEditionNft(connection, wallet, owner, {
        name: "Course NFT #1 — Genesis Block",
        symbol: "CRSCOL",
        uri: `${LECTURE_14_BASE_URI}/nft_1.json`,
        collection: { key: collection.mint, verified: false },
        collectionDetails: null,
      });
      infoOut(log, "nft1 mint", nft1.mint.toBase58());

      stepOut(
        log,
        "3. tx#3 — VerifySizedCollectionItem #1 (signed by collection authority = wallet) — confirm",
      );
      await sendWithWallet(
        connection,
        wallet,
        new Transaction().add(
          createVerifySizedCollectionItemInstruction({
            metadata: nft1.metadataPda,
            collectionAuthority: owner,
            payer: owner,
            collectionMint: collection.mint,
            collection: collection.metadataPda,
            collectionMasterEditionAccount: collection.editionPda,
          }),
        ),
        [],
      );

      stepOut(
        log,
        "4. tx#4 — NFT #2 (другой URI и атрибуты) — confirm in wallet",
      );
      const nft2 = await createMasterEditionNft(connection, wallet, owner, {
        name: "Course NFT #2 — Slot Leader",
        symbol: "CRSCOL",
        uri: `${LECTURE_14_BASE_URI}/nft_2.json`,
        collection: { key: collection.mint, verified: false },
        collectionDetails: null,
      });
      infoOut(log, "nft2 mint", nft2.mint.toBase58());

      stepOut(log, "5. tx#5 — VerifySizedCollectionItem #2 — confirm in wallet");
      await sendWithWallet(
        connection,
        wallet,
        new Transaction().add(
          createVerifySizedCollectionItemInstruction({
            metadata: nft2.metadataPda,
            collectionAuthority: owner,
            payer: owner,
            collectionMint: collection.mint,
            collection: collection.metadataPda,
            collectionMasterEditionAccount: collection.editionPda,
          }),
        ),
        [],
      );

      stepOut(log, "6. читаем итоговое состояние трёх Metadata-аккаунтов");
      const collectionAcc = await connection.getAccountInfo(
        collection.metadataPda,
        "confirmed",
      );
      if (!collectionAcc) throw new Error("collection metadata not found");
      const [collectionMeta] = Metadata.deserialize(collectionAcc.data);
      const detailsLabel =
        collectionMeta.collectionDetails &&
        isCollectionDetailsV1(collectionMeta.collectionDetails)
          ? `V1 size=${String(collectionMeta.collectionDetails.size)}`
          : "(none)";
      infoOut(log, "collection.collectionDetails", detailsLabel);

      for (const [label, child] of [
        ["nft1", nft1],
        ["nft2", nft2],
      ] as const) {
        const acc = await connection.getAccountInfo(
          child.metadataPda,
          "confirmed",
        );
        if (!acc) throw new Error(`${label} metadata not found`);
        const [meta] = Metadata.deserialize(acc.data);
        const c = meta.collection;
        const collLabel = c
          ? `key=${shortPk(new PublicKey(c.key))}, verified=${c.verified}`
          : "(none)";
        infoOut(log, `${label}.name`, meta.data.name.replace(/\u0000/g, ""));
        infoOut(log, `${label}.uri`, meta.data.uri.replace(/\u0000/g, ""));
        infoOut(log, `${label}.collection`, collLabel);
      }

      log(
        "\n  Итог: collection — это обычный Master Edition NFT с пометкой collectionDetails.V1.size,",
      );
      log(
        "       поле collection в члене коллекции — это claim; verified=true появляется только",
      );
      log(
        "       после VerifySizedCollectionItem, подписанного update authority родителя.",
      );
      log(
        "       Программа Metaplex автоматически инкрементит size в parent NFT при каждой verify.",
      );
    } catch (e) {
      log(String(e));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="tabBody">
      <p className="lede">
        Как <code>06_collection_nft.ts</code>: одна collection NFT + два member
        NFT, каждый «принимается в семью» отдельной инструкцией{" "}
        <code>VerifySizedCollectionItem</code>. Phantom попросит подпись на 5
        транзакций (1 collection + 2 NFT + 2 verify).
      </p>
      <div className="row">
        <button type="button" disabled={running} onClick={run}>
          {running ? "Running…" : "Run demo 6"}
        </button>
      </div>
      <ScrollingLog
        lines={lines}
        emptyPlaceholder="Output updates after each wallet step (same as console)."
      />
    </div>
  );
}
