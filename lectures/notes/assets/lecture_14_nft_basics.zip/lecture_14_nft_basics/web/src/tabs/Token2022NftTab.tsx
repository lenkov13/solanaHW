import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { useState } from "react";
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  AuthorityType,
  ExtensionType,
  LENGTH_SIZE,
  TOKEN_2022_PROGRAM_ID,
  TYPE_SIZE,
  createAssociatedTokenAccountInstruction,
  createInitializeMetadataPointerInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  createSetAuthorityInstruction,
  getAccount,
  getAssociatedTokenAddressSync,
  getMint,
  getMintLen,
  getTokenMetadata,
} from "@solana/spl-token";
import {
  createInitializeInstruction,
  pack,
  type TokenMetadata,
} from "@solana/spl-token-metadata";
import {
  ComputeBudgetProgram,
  Keypair,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";
import { ScrollingLog } from "../components/ScrollingLog";
import { sendWithWallet } from "../lib/sendWallet";
import {
  fmtAmount,
  infoOut,
  makeAppendLog,
  sectionOut,
  shortPk,
  stepOut,
} from "../lib/logFormat";

const DECIMALS = 0;

export function Token2022NftTab() {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [lines, setLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    if (!wallet.publicKey) {
      setLines(["Connect Phantom first."]);
      return;
    }
    setRunning(true);
    setLines([]);
    const log = makeAppendLog(setLines);
    const wb = wallet;
    try {
      sectionOut(log, "Demo 2 — Token-2022 NFT с встроенной Metadata");
      const owner = wb.publicKey!;
      const mintKp = Keypair.generate();

      const metadata: TokenMetadata = {
        mint: mintKp.publicKey,
        name: "Course NFT — L14",
        symbol: "CRSNFT",
        uri: "https://example.com/lecture-14/nft.json",
        additionalMetadata: [
          ["category", "education"],
          ["lecture", "14"],
        ],
      };

      stepOut(
        log,
        "1. размеры: mintLen + metadataLen; lamports = rent за полный размер — no tx",
      );
      const mintLen = getMintLen([ExtensionType.MetadataPointer]);
      const metadataLen = TYPE_SIZE + LENGTH_SIZE + pack(metadata).length;
      const lamports = await connection.getMinimumBalanceForRentExemption(
        mintLen + metadataLen,
        "confirmed",
      );
      infoOut(log, "mint", mintKp.publicKey.toBase58());
      infoOut(log, "mint len (space)", mintLen);
      infoOut(log, "metadata len", metadataLen);
      infoOut(log, "rent for full", lamports);

      stepOut(
        log,
        "2. createAccount → initMetadataPointer → initMint2(0) → initMetadata — confirm in wallet",
      );
      const initTx = new Transaction().add(
        ComputeBudgetProgram.setComputeUnitLimit({ units: 400_000 }),
        SystemProgram.createAccount({
          fromPubkey: owner,
          newAccountPubkey: mintKp.publicKey,
          space: mintLen,
          lamports,
          programId: TOKEN_2022_PROGRAM_ID,
        }),
        createInitializeMetadataPointerInstruction(
          mintKp.publicKey,
          owner,
          mintKp.publicKey,
          TOKEN_2022_PROGRAM_ID,
        ),
        createInitializeMint2Instruction(
          mintKp.publicKey,
          DECIMALS,
          owner,
          null,
          TOKEN_2022_PROGRAM_ID,
        ),
        createInitializeInstruction({
          programId: TOKEN_2022_PROGRAM_ID,
          mint: mintKp.publicKey,
          metadata: mintKp.publicKey,
          name: metadata.name,
          symbol: metadata.symbol,
          uri: metadata.uri,
          mintAuthority: owner,
          updateAuthority: owner,
        }),
      );
      await sendWithWallet(connection, wb, initTx, [mintKp]);

      const ata = getAssociatedTokenAddressSync(
        mintKp.publicKey,
        owner,
        false,
        TOKEN_2022_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID,
      );
      stepOut(
        log,
        "3. createAssociatedTokenAccount + mintTo(1) — confirm in wallet",
      );
      const mintTx = new Transaction()
        .add(
          createAssociatedTokenAccountInstruction(
            owner,
            ata,
            owner,
            mintKp.publicKey,
            TOKEN_2022_PROGRAM_ID,
            ASSOCIATED_TOKEN_PROGRAM_ID,
          ),
        )
        .add(
          createMintToInstruction(
            mintKp.publicKey,
            ata,
            owner,
            1n,
            [],
            TOKEN_2022_PROGRAM_ID,
          ),
        );
      await sendWithWallet(connection, wb, mintTx, []);
      infoOut(log, "ata", shortPk(ata));

      stepOut(
        log,
        "4. setAuthority(MintTokens, null) — supply = 1 фиксируется навсегда — confirm in wallet",
      );
      const authTx = new Transaction().add(
        createSetAuthorityInstruction(
          mintKp.publicKey,
          owner,
          AuthorityType.MintTokens,
          null,
          [],
          TOKEN_2022_PROGRAM_ID,
        ),
      );
      await sendWithWallet(connection, wb, authTx, []);

      stepOut(log, "5. читаем mint, metadata и ATA (RPC)");
      const mintInfo = await getMint(
        connection,
        mintKp.publicKey,
        "confirmed",
        TOKEN_2022_PROGRAM_ID,
      );
      const ataInfo = await getAccount(
        connection,
        ata,
        "confirmed",
        TOKEN_2022_PROGRAM_ID,
      );
      infoOut(log, "decimals", mintInfo.decimals);
      infoOut(log, "supply", mintInfo.supply.toString());
      infoOut(
        log,
        "mintAuthority",
        mintInfo.mintAuthority?.toBase58() ?? "null",
      );
      infoOut(log, "ata amount", fmtAmount(ataInfo.amount, mintInfo.decimals));

      const onChain = await getTokenMetadata(connection, mintKp.publicKey);
      if (onChain) {
        infoOut(log, "name", onChain.name);
        infoOut(log, "symbol", onChain.symbol);
        infoOut(log, "uri", onChain.uri);
        infoOut(
          log,
          "additional",
          onChain.additionalMetadata
            .map(([k, v]) => `${k}=${v}`)
            .join(", ") || "(empty)",
        );
      }

      const isNft =
        mintInfo.decimals === 0 &&
        mintInfo.supply === 1n &&
        mintInfo.mintAuthority === null &&
        ataInfo.amount === 1n;
      infoOut(
        log,
        "verdict",
        isNft ? "✓ это валидный Token-2022 NFT" : "✗ ещё не NFT",
      );

      log(
        "\n  Итог: Token-2022 NFT — самый «честный» формат: всё про токен и его metadata живёт в одном аккаунте.",
      );
      log(
        "       Никакой отдельной Metaplex-программы не требуется — кошельки понимают этот формат напрямую.",
      );
    } catch (e) {
      log(String(e));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="tabBody">
      <p className="lede">
        Как <code>02_token2022_nft.ts</code>: <code>space = mintLen</code>, rent
        за <code>mintLen + metadataLen</code>, порядок MetadataPointer →{" "}
        <code>initMint2(0)</code> → Metadata → <code>mintTo(1)</code> →{" "}
        <code>setAuthority(null)</code>.
      </p>
      <div className="row">
        <button type="button" disabled={running} onClick={run}>
          {running ? "Running…" : "Run demo 2"}
        </button>
      </div>
      <ScrollingLog
        lines={lines}
        emptyPlaceholder="Output updates after each wallet step (same as console)."
      />
    </div>
  );
}
