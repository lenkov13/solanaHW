import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { useState } from "react";
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  AuthorityType,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  createSetAuthorityInstruction,
  getAccount,
  getAssociatedTokenAddressSync,
  getMint,
  getMinimumBalanceForRentExemptMint,
} from "@solana/spl-token";
import {
  Keypair,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";
import { ScrollingLog } from "../components/ScrollingLog";
import { sendWithWallet } from "../lib/sendWallet";
import {
  fmtAmount,
  infoOut,
  makeAppendLog,
  sectionOut,
  shortPk,
  stepOut,
} from "../lib/logFormat";

const DECIMALS = 0;

export function SplNftTab() {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [lines, setLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    if (!wallet.publicKey) {
      setLines(["Connect Phantom first."]);
      return;
    }
    setRunning(true);
    setLines([]);
    const log = makeAppendLog(setLines);
    const wb = wallet;
    try {
      sectionOut(log, "Demo 1 — SPL classic NFT (Token Program, без Metaplex)");
      const owner = wb.publicKey!;
      const mintKp = Keypair.generate();

      stepOut(
        log,
        "1. createMint(decimals = 0, mintAuthority = owner) — confirm in wallet",
      );
      const lamports = await getMinimumBalanceForRentExemptMint(connection);
      const createMintTx = new Transaction().add(
        SystemProgram.createAccount({
          fromPubkey: owner,
          newAccountPubkey: mintKp.publicKey,
          space: MINT_SIZE,
          lamports,
          programId: TOKEN_PROGRAM_ID,
        }),
        createInitializeMint2Instruction(
          mintKp.publicKey,
          DECIMALS,
          owner,
          null,
          TOKEN_PROGRAM_ID,
        ),
      );
      await sendWithWallet(connection, wb, createMintTx, [mintKp]);
      const mint = mintKp.publicKey;
      infoOut(log, "mint", mint.toBase58());

      const ata = getAssociatedTokenAddressSync(
        mint,
        owner,
        false,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID,
      );

      stepOut(
        log,
        "2. createAssociatedTokenAccount + mintTo(1) — confirm in wallet",
      );
      const txMint = new Transaction()
        .add(
          createAssociatedTokenAccountInstruction(
            owner,
            ata,
            owner,
            mint,
            TOKEN_PROGRAM_ID,
            ASSOCIATED_TOKEN_PROGRAM_ID,
          ),
        )
        .add(
          createMintToInstruction(
            mint,
            ata,
            owner,
            1n,
            [],
            TOKEN_PROGRAM_ID,
          ),
        );
      await sendWithWallet(connection, wb, txMint, []);
      infoOut(log, "ata", shortPk(ata));

      stepOut(
        log,
        "3. setAuthority(MintTokens, null) — supply = 1 фиксируется навсегда — confirm in wallet",
      );
      const txAuth = new Transaction().add(
        createSetAuthorityInstruction(
          mint,
          owner,
          AuthorityType.MintTokens,
          null,
          [],
          TOKEN_PROGRAM_ID,
        ),
      );
      await sendWithWallet(connection, wb, txAuth, []);

      stepOut(log, "4. читаем mint и ATA, валидируем критерии (RPC)");
      const mintInfo = await getMint(
        connection,
        mint,
        "confirmed",
        TOKEN_PROGRAM_ID,
      );
      const ataInfo = await getAccount(
        connection,
        ata,
        "confirmed",
        TOKEN_PROGRAM_ID,
      );
      infoOut(log, "decimals", mintInfo.decimals);
      infoOut(log, "supply", mintInfo.supply.toString());
      infoOut(
        log,
        "mintAuthority",
        mintInfo.mintAuthority?.toBase58() ?? "null",
      );
      infoOut(
        log,
        "freezeAuthority",
        mintInfo.freezeAuthority?.toBase58() ?? "null",
      );
      infoOut(log, "ata amount", fmtAmount(ataInfo.amount, mintInfo.decimals));

      const isNft =
        mintInfo.decimals === 0 &&
        mintInfo.supply === 1n &&
        mintInfo.mintAuthority === null &&
        ataInfo.amount === 1n;
      infoOut(
        log,
        "verdict",
        isNft ? "✓ это валидный SPL NFT" : "✗ ещё не NFT",
      );

      log(
        "\n  Итог: NFT — это паттерн использования mint, а не отдельный тип аккаунта.",
      );
      log(
        "       Чтобы превратить токен в NFT, достаточно decimals=0, mintTo(1) и revoke mint authority.",
      );
    } catch (e) {
      log(String(e));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="tabBody">
      <p className="lede">
        Как <code>01_spl_nft.ts</code>: <code>createMint(0)</code> → ATA →{" "}
        <code>mintTo(1)</code> → <code>setAuthority(null)</code>. Подписи через
        Phantom; лог обновляется после каждого шага.
      </p>
      <div className="row">
        <button type="button" disabled={running} onClick={run}>
          {running ? "Running…" : "Run demo 1"}
        </button>
      </div>
      <ScrollingLog
        lines={lines}
        emptyPlaceholder="Output appears here after each wallet step (same as console)."
      />
    </div>
  );
}
