import { useConnection } from "@solana/wallet-adapter-react";
import { useState } from "react";
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Metadata,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  TOKEN_2022_PROGRAM_ID,
  TOKEN_PROGRAM_ID,
  getAccount,
  getMint,
  getTokenMetadata,
} from "@solana/spl-token";
import { Connection, PublicKey } from "@solana/web3.js";
import { ScrollingLog } from "../components/ScrollingLog";
import {
  infoOut,
  makeAppendLog,
  sectionOut,
  shortPk,
  stepOut,
} from "../lib/logFormat";

interface ProbeResult {
  programId: PublicKey;
  decimals: number;
  supply: bigint;
  mintAuthority: PublicKey | null;
  freezeAuthority: PublicKey | null;
  owner?: PublicKey;
  ataAmount?: bigint;
  name?: string;
  symbol?: string;
  uri?: string;
  metadataSource: "token-2022" | "metaplex" | "none";
  authorityFix: "revoked-null" | "metaplex-edition" | "open";
}

function findEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

async function detectMintProgram(
  conn: Connection,
  mint: PublicKey,
): Promise<PublicKey> {
  const acc = await conn.getAccountInfo(mint, "confirmed");
  if (!acc) throw new Error(`mint ${mint.toBase58()} not found on-chain`);
  if (acc.owner.equals(TOKEN_PROGRAM_ID)) return TOKEN_PROGRAM_ID;
  if (acc.owner.equals(TOKEN_2022_PROGRAM_ID)) return TOKEN_2022_PROGRAM_ID;
  throw new Error(
    `mint ${mint.toBase58()} owned by неизвестная программа: ${acc.owner.toBase58()}`,
  );
}

async function probeNft(
  conn: Connection,
  mint: PublicKey,
): Promise<ProbeResult> {
  const programId = await detectMintProgram(conn, mint);
  const mintInfo = await getMint(conn, mint, "confirmed", programId);

  const editionPda = findEditionPda(mint);
  let authorityFix: ProbeResult["authorityFix"];
  if (mintInfo.mintAuthority === null) {
    authorityFix = "revoked-null";
  } else if (mintInfo.mintAuthority.equals(editionPda)) {
    authorityFix = "metaplex-edition";
  } else {
    authorityFix = "open";
  }

  const result: ProbeResult = {
    programId,
    decimals: mintInfo.decimals,
    supply: mintInfo.supply,
    mintAuthority: mintInfo.mintAuthority,
    freezeAuthority: mintInfo.freezeAuthority,
    metadataSource: "none",
    authorityFix,
  };

  try {
    const largest = await conn.getTokenLargestAccounts(mint, "confirmed");
    const top = largest.value[0];
    if (top) {
      const ataInfo = await getAccount(
        conn,
        top.address,
        "confirmed",
        programId,
      );
      result.owner = ataInfo.owner;
      result.ataAmount = ataInfo.amount;
    }
  } catch {

  }

  if (programId.equals(TOKEN_2022_PROGRAM_ID)) {
    const m = await getTokenMetadata(conn, mint);
    if (m) {
      result.name = m.name;
      result.symbol = m.symbol;
      result.uri = m.uri;
      result.metadataSource = "token-2022";
    }
  }

  if (result.metadataSource === "none") {

    const metadataPda = PublicKey.findProgramAddressSync(
      [
        Buffer.from("metadata"),
        TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
      ],
      TOKEN_METADATA_PROGRAM_ID,
    )[0];
    const acc = await conn.getAccountInfo(metadataPda, "confirmed");
    if (acc) {
      const [meta] = Metadata.deserialize(acc.data);
      result.name = meta.data.name.replace(/\u0000/g, "");
      result.symbol = meta.data.symbol.replace(/\u0000/g, "");
      result.uri = meta.data.uri.replace(/\u0000/g, "");
      result.metadataSource = "metaplex";
    }
  }

  return result;
}

function isNft(p: ProbeResult): boolean {
  return (
    p.decimals === 0 &&
    p.supply === 1n &&
    p.authorityFix !== "open" &&
    p.ataAmount === 1n
  );
}

export function ReadNftTab({ clusterLabel }: { clusterLabel: string }) {
  const { connection } = useConnection();
  const [mintAddr, setMintAddr] = useState("");
  const [lines, setLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);

  async function run() {
    if (!mintAddr.trim()) {
      setLines(["Введите адрес mint в поле выше."]);
      return;
    }
    setRunning(true);
    setLines([]);
    const log = makeAppendLog(setLines);
    try {
      sectionOut(log, "Demo 4 — universal read & validate NFT");
      let mint: PublicKey;
      try {
        mint = new PublicKey(mintAddr.trim());
      } catch {
        log("Невалидный адрес — это должен быть base58 pubkey.");
        return;
      }

      stepOut(log, "1. определяем program-owner и читаем mint info");
      const probe = await probeNft(connection, mint);
      infoOut(log, "mint", mint.toBase58());
      infoOut(
        log,
        "program",
        probe.programId.equals(TOKEN_2022_PROGRAM_ID) ? "Token-2022" : "Token",
      );
      infoOut(log, "decimals", probe.decimals);
      infoOut(log, "supply", probe.supply.toString());
      infoOut(
        log,
        "mintAuthority",
        probe.mintAuthority?.toBase58() ?? "null",
      );
      infoOut(
        log,
        "freezeAuthority",
        probe.freezeAuthority?.toBase58() ?? "null",
      );
      if (probe.owner) {
        infoOut(log, "owner", shortPk(probe.owner));
        infoOut(log, "ata amount", probe.ataAmount?.toString() ?? "?");
      } else {
        infoOut(log, "owner", "(нет держателя)");
      }

      stepOut(log, "2. metadata");
      infoOut(log, "source", probe.metadataSource);
      if (probe.metadataSource !== "none") {
        infoOut(log, "name", probe.name ?? "");
        infoOut(log, "symbol", probe.symbol ?? "");
        infoOut(log, "uri", probe.uri ?? "");
      } else {
        infoOut(
          log,
          "name",
          "(нет metadata — ни Token-2022, ни Metaplex)",
        );
      }

      stepOut(log, "3. вердикт + explorer");
      const fixLabel: Record<ProbeResult["authorityFix"], string> = {
        "revoked-null": "mintAuthority = null (классический revoke)",
        "metaplex-edition": "mintAuthority = master edition PDA (Metaplex)",
        "open": "mintAuthority открыт — supply не зафиксирован",
      };
      infoOut(log, "authority fix", fixLabel[probe.authorityFix]);
      const verdict = isNft(probe) ? "✓ это валидный NFT" : "✗ не NFT";
      infoOut(log, "verdict", verdict);
      const suffix =
        clusterLabel === "mainnet-beta" ? "" : `?cluster=${clusterLabel}`;
      const explorer = `https://explorer.solana.com/address/${mint.toBase58()}${suffix}`;
      infoOut(log, "explorer", explorer);

      log(
        "\n  Итог: mintAuthority может быть null (SPL/Token-2022 школа) либо master edition PDA (Metaplex школа) —",
      );
      log(
        "       обе формы корректно фиксируют supply = 1.",
      );
    } catch (e) {
      log(String(e));
    } finally {
      setRunning(false);
    }
  }

  return (
    <div className="tabBody">
      <p className="lede">
        Как <code>04_read_nft.ts</code>: вводите адрес mint, узнаёте program,
        decimals/supply/authorities, источник metadata и вердикт «is NFT».
        Этот же приёмник можно использовать для любого токена.
      </p>
      <div
        className="row"
        style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}
      >
        <input
          type="text"
          value={mintAddr}
          onChange={(e) => setMintAddr(e.target.value)}
          placeholder="mint address (base58)"
          style={{
            flex: "1 1 18rem",
            padding: "0.5rem 0.6rem",
            background: "#0d1117",
            color: "#e6edf3",
            border: "1px solid #30363d",
            borderRadius: "6px",
            fontFamily: "ui-monospace, monospace",
            fontSize: "0.8rem",
          }}
        />
        <button type="button" disabled={running} onClick={run}>
          {running ? "Reading…" : "Read mint"}
        </button>
      </div>
      <ScrollingLog
        lines={lines}
        emptyPlaceholder="Введите адрес mint и нажмите Read mint."
      />
    </div>
  );
}
