import "./polyfills";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import {
  ConnectionProvider,
  WalletProvider,
} from "@solana/wallet-adapter-react";
import { WalletModalProvider } from "@solana/wallet-adapter-react-ui";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-phantom";
import App from "./App";
import { ErrorBoundary } from "./ErrorBoundary";
import { getClusterEndpoint, parseCluster } from "./lib/cluster";
import "./App.css";
import "@solana/wallet-adapter-react-ui/styles.css";

const cluster = parseCluster();
const endpoint =
  import.meta.env.VITE_SOLANA_RPC?.trim() || getClusterEndpoint(cluster);

const CONNECTION_CONFIG = { commitment: "confirmed" as const };
const wallets = [new PhantomWalletAdapter()];

function Root() {
  return (
    <StrictMode>
      <ErrorBoundary>
        <ConnectionProvider endpoint={endpoint} config={CONNECTION_CONFIG}>
          <WalletProvider
            wallets={wallets}
            autoConnect
            onError={(e) => {
              const inner = (e as { error?: unknown }).error;
              console.error("WalletProvider onError:", e, inner);
            }}
          >
            <WalletModalProvider>
              <App clusterLabel={cluster} defaultRpc={endpoint} />
            </WalletModalProvider>
          </WalletProvider>
        </ConnectionProvider>
      </ErrorBoundary>
    </StrictMode>
  );
}

const root = document.getElementById("root");
if (root) createRoot(root).render(<Root />);
