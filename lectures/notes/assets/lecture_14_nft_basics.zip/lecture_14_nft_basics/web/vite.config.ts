import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { nodePolyfills } from "vite-plugin-node-polyfills";

// Metaplex Umi pulls a few Node built-ins (stream/http/url) at module init
// — без полифилов на старте бандла падает `Cannot read properties of undefined
// (reading 'prototype')`. nodePolyfills() закрывает все нужные импорты
// (включая Buffer + globalThis), поэтому отдельный alias на buffer больше не нужен.
export default defineConfig({
  plugins: [
    react(),
    nodePolyfills({
      protocolImports: true,
      globals: { Buffer: true, global: true, process: true },
    }),
  ],
  define: {
    "process.env": {},
  },
  optimizeDeps: {
    esbuildOptions: {
      define: { global: "globalThis" },
    },
  },
});
