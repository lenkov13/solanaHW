# Лекция 14 — NFT на Solana: основы

Иллюстративный проект к занятию 14. Шесть независимых демо на TypeScript,
которые показывают «механику» NFT прямо в devnet — до того, как в лекции 15
мы перейдём к Candy Machine.

## Что внутри

| Демо | Тема                                                                                            | Файл                                                            |
|------|-------------------------------------------------------------------------------------------------|-----------------------------------------------------------------|
| 1    | SPL classic NFT: `createMint(0)` → ATA → `mintTo(1)` → revoke mint                              | [`src/demos/01_spl_nft.ts`](src/demos/01_spl_nft.ts)            |
| 2    | Token-2022 NFT с встроенной Metadata + revoke mint authority                                    | [`src/demos/02_token2022_nft.ts`](src/demos/02_token2022_nft.ts) |
| 3    | Metaplex Token Metadata «руками»: 3 транзакции, 2 PDA, без SDK поверх web3.js                   | [`src/demos/03_metaplex_metadata.ts`](src/demos/03_metaplex_metadata.ts) |
| 4    | Print Editions: series-master c `maxSupply > 0` + копии через `MintNewEditionFromMasterEditionViaToken` | [`src/demos/04_print_edition.ts`](src/demos/04_print_edition.ts) |
| 5    | Чтение и валидация NFT по адресу mint (универсальный приёмник, manual `Metadata.deserialize`)   | [`src/demos/05_read_nft.ts`](src/demos/05_read_nft.ts)          |
| 6    | Sized Collection NFT + два verified члена (`VerifySizedCollectionItem`)                         | [`src/demos/06_collection_nft.ts`](src/demos/06_collection_nft.ts) |

## Off-chain metadata

Все JSON-метаданные демо (и одна общая SVG-«картинка») лежат в
[`web/public/lecture-14/`](web/public/lecture-14/). Vite автоматически отдаёт
эту папку по корневому пути, поэтому файлы доступны как
`http://localhost:5173/lecture-14/<file>.json`. Демо записывают именно этот
URL on-chain в `DataV2.uri`, и пока крутится Vite-сервер, любой клиент
(Phantom, Solana Explorer, индексатор) сможет его открыть и прочитать.

| Файл                                | Кем используется    |
|-------------------------------------|---------------------|
| `02_token2022.json`                 | demo 2              |
| `03_metaplex.json`                  | demo 3              |
| `04_print_series.json`              | demo 4 (master, копии наследуют) |
| `collection.json` / `nft_1.json` / `nft_2.json` | demo 6 |
| `card.svg`                          | общая `image` ссылка |

## Web UI (Phantom, браузер)

Те же шесть демо во вкладках, с подписью через Phantom и логом «как в консоли».
Web-сервер же одновременно хостит off-chain JSON для всех демо — так что
держать его запущенным желательно даже когда работаете в консоли.

```bash
cd lecture_14_nft_basics/web
npm install
npm run dev
```

Откройте URL из терминала, переключите Phantom на **Devnet**, при необходимости
нажмите **Airdrop 1 SOL**, затем **Run demo** на нужной вкладке.

Параметры (опционально, Vite):

- `VITE_SOLANA_CLUSTER=devnet` (по умолчанию devnet)
- `VITE_SOLANA_RPC=https://...` — свой RPC
- `VITE_LECTURE_14_BASE_URI=https://...` — переопределить базовый URL для off-chain JSON (по умолчанию берётся `window.location.origin + "/lecture-14"`)

## Быстрый старт (CLI)

```bash
cd lecture_14_nft_basics
npm install
npm run start            # последовательно прогонит все шесть демо
```

Отдельные демо:

```bash
npm run demo:1           # SPL classic NFT
npm run demo:2           # Token-2022 NFT
npm run demo:3           # Metaplex Token Metadata
npm run demo:4           # Print Editions
npm run demo:5           # read & validate NFT
npm run demo:6           # Collection NFT + verify
```

Демо `demo:5` принимает адрес mint через переменную окружения:

```bash
NFT_MINT=<base58 mint address> npm run demo:5
```

Если `NFT_MINT` не указан — скрипт сам выпустит небольшой Token-2022 NFT
и прочитает его, чтобы получить «зелёный путь».

Все консольные демо по умолчанию ставят URI вида
`http://localhost:5173/lecture-14/<file>.json`. **Чтобы эти URL были живыми,
запустите `npm run dev` в `web/` параллельно** — Vite будет одновременно и
держать UI, и отдавать off-chain JSON. Если нужен другой хост (Arweave / GitHub
raw / ngrok туннель), переопределите через env:

```bash
LECTURE_14_BASE_URI=https://arweave.net/abc123 npm run start
```

## Где берётся payer и SOL

Скрипт по очереди пробует:

1. путь из `WALLET_KEYPAIR=/path/to/keypair.json`
2. `../wallet-keypair.json` (тот самый, что уже лежит в корне репозитория)
3. если ничего не найдено — генерирует новый keypair и просит airdrop в devnet

Если баланс payer-а ниже 0.2 SOL — автоматически запрашивает airdrop на 1 SOL
(только в devnet).

```bash
SOLANA_CLUSTER=devnet npm run start
SOLANA_RPC=https://api.devnet.solana.com npm run start
```

## Что стоит показать студентам

1. **Demo 1** объясняет: «NFT» — это просто SPL-токен с `decimals = 0`,
   `mintTo(1)` и снятым `mintAuthority`. Ни одной новой программы.

2. **Demo 2** показывает «современный путь»: Token-2022 + MetadataPointer +
   Metadata extension хранят имя/символ/URI прямо на mint. Порядок init:
   `createAccount → initMetadataPointer → initMint2 → initMetadata → mintTo(1) → setAuthority(null)`.

3. **Demo 3** — Metaplex Token Metadata изнутри. Никакого Umi: студент
   видит, что Metaplex — это **одна on-chain программа** + два PDA-аккаунта
   (metadata и master edition) + две инструкции
   (`CreateMetadataAccountV3`, `CreateMasterEditionV3`). Транзакция
   разложена на три шага:
   1. обычный SPL `createAccount + initMint2(0) + ATA + mintTo(1)` —
      «токен есть, но это ещё НЕ NFT»;
   2. `CreateMetadataAccountV3` записывает `DataV2` (name/symbol/uri/
      sellerFeeBasisPoints/creators) в metadata-PDA;
   3. `CreateMasterEditionV3(maxSupply=0)` забирает `mintAuthority` и
      `freezeAuthority` себе — supply=1 фиксируется навсегда.

   PDA вычисляются вручную через
   `PublicKey.findProgramAddressSync(["metadata", program, mint, ?"edition"])` —
   ровно так, как это делает любая программа на Solana.

4. **Demo 4** — Print Editions поверх Master Edition. Создаём «series
   master» с `maxSupply: 3` (вместо 0 как в demo 3) и печатаем 2 копии.
   Каждая копия — это **отдельный полноценный NFT** со своим mint, своим
   `Metadata` PDA (с *скопированными* `name/symbol/uri` от родителя) и
   собственным `Edition` PDA (`key = EditionV1`, `parent = master mint`,
   `edition = N`). Программа Metaplex автоматически:
   - инкрементит `Master.supply`,
   - ставит бит `N` в `EditionMarker` PDA (битовая карта на 248 номеров —
     гарантия, что `#N` уникален),
   - переносит `mintAuthority/freezeAuthority` копии в её собственный edition
     PDA, фиксируя её `supply = 1`.

   Print Edition требует, чтобы caller **сам** подготовил новый mint с
   `supply = 1` ДО вызова — иначе программа отвечает
   `Editions must have exactly one token`.

5. **Demo 5** — универсальное чтение. Берём адрес mint, узнаём program id
   (TOKEN_PROGRAM_ID или TOKEN_2022_PROGRAM_ID), читаем `mint`, `ata`, и
   metadata из соответствующего источника. Для Metaplex — `getAccountInfo`
   на metadata-PDA + `Metadata.deserialize`. Печатаем вердикт «is NFT».
   Признаёт обе «школы» supply-фиксации: `mintAuthority = null` (SPL/Token-2022)
   и `mintAuthority = master edition PDA` (Metaplex).

6. **Demo 6** — Collection NFT и членство. Пять транзакций, чисто на raw
   web3.js + mpl-token-metadata:
   1. **collection NFT** — Master Edition + `collectionDetails: V1{ size: 0 }`.
      Это поле и делает обычный NFT «коллекцией».
   2. **NFT #1** с `collection: { key: <collection mint>, verified: false }` —
      это пока только **claim** членства, не доказательство.
   3. **`VerifySizedCollectionItem` для NFT #1** — подписывает update
      authority parent NFT (= наш payer). Программа Metaplex проверяет
      подпись и ставит `verified = true`, попутно инкрементируя
      `parent.collectionDetails.V1.size`.
   4. **NFT #2** — то же что #1, но другой URI и атрибуты.
   5. **`VerifySizedCollectionItem` для NFT #2** — `parent.size` становится 2.

   Off-chain JSON-ы лежат в `web/public/lecture-14/{collection,nft_1,nft_2}.json`
   и отдаются Vite-сервером на `http://localhost:5173/lecture-14/...` —
   именно этот URL уходит on-chain в `DataV2.uri`. На production его место
   занял бы Arweave / IPFS / Cloudflare R2.

## Структура проекта

```
lecture_14_nft_basics/
├── package.json
├── tsconfig.json
├── README.md
├── web/                                # React + Vite + Phantom (npm run dev)
│   ├── package.json
│   ├── public/
│   │   └── lecture-14/                 # off-chain JSON + общая SVG-картинка
│   │       ├── card.svg
│   │       ├── 02_token2022.json
│   │       ├── 03_metaplex.json
│   │       ├── 04_print_series.json
│   │       ├── collection.json
│   │       ├── nft_1.json
│   │       └── nft_2.json
│   └── src/
│       ├── lib/metadata.ts             # LECTURE_14_BASE_URI для web
│       └── tabs/…
└── src/
    ├── index.ts                        # orchestrator (npm start)
    ├── helpers.ts                      # connection, payer, LECTURE_14_BASE_URI
    └── demos/
        ├── 01_spl_nft.ts
        ├── 02_token2022_nft.ts
        ├── 03_metaplex_metadata.ts
        ├── 04_print_edition.ts
        ├── 05_read_nft.ts
        └── 06_collection_nft.ts
```

## Связь с лекцией

- Слайд 4 («что такое NFT») → Demo 1 + Demo 5
- Слайд 6 («SPL classic NFT») → Demo 1
- Слайд 7 («Token-2022 NFT») → Demo 2
- Слайд 8 («Metaplex Token Metadata») → Demo 3
- Слайд 10 («Master & Print Editions») → Demo 4
- Слайд 11 («Collections») → Demo 6
- Слайд 19 («код: чтение NFT») → Demo 5
- Семинарный слайд — связка всех шести демо плюс web/.
