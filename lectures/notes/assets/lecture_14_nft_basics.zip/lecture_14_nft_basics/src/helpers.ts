import * as fs from "fs";
import * as path from "path";
import {
  clusterApiUrl,
  Commitment,
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
  PublicKey,
  Signer,
  SystemProgram,
  Transaction,
  sendAndConfirmTransaction,
} from "@solana/web3.js";

export const CLUSTER: "devnet" | "mainnet-beta" | "testnet" =
  (process.env.SOLANA_CLUSTER as any) || "devnet";

export const LECTURE_14_BASE_URI: string =
  process.env.LECTURE_14_BASE_URI?.trim()?.replace(/\/$/, "") ||
  "http://localhost:5173/lecture-14";

export function makeConnection(): Connection {
  const endpoint = process.env.SOLANA_RPC?.trim() || clusterApiUrl(CLUSTER);
  return new Connection(endpoint, "confirmed");
}

export function loadKeypairFromJson(filePath: string): Keypair {
  const raw = JSON.parse(fs.readFileSync(filePath, "utf8")) as number[];
  return Keypair.fromSecretKey(Uint8Array.from(raw));
}

export async function loadOrCreatePayer(conn: Connection): Promise<Keypair> {
  const envPath = process.env.WALLET_KEYPAIR?.trim();
  const defaultPath = path.join(__dirname, "..", "..", "wallet-keypair.json");
  const candidatePath = envPath || defaultPath;

  if (fs.existsSync(candidatePath)) {
    const kp = loadKeypairFromJson(candidatePath);
    const bal = await conn.getBalance(kp.publicKey);
    console.log(
      `[payer] loaded ${kp.publicKey.toBase58()} from ${candidatePath}`,
    );
    console.log(`[payer] balance: ${(bal / LAMPORTS_PER_SOL).toFixed(4)} SOL`);
    if (bal < 0.2 * LAMPORTS_PER_SOL && CLUSTER === "devnet") {
      await requestAirdropSafe(conn, kp.publicKey, 1);
    }
    return kp;
  }

  console.log("[payer] no keypair found — generating new one for this run");
  const kp = Keypair.generate();
  await requestAirdropSafe(conn, kp.publicKey, 2);
  return kp;
}

export async function requestAirdropSafe(
  conn: Connection,
  pubkey: PublicKey,
  sol: number,
): Promise<void> {
  if (CLUSTER !== "devnet") {
    console.log(`[airdrop] skipped (cluster=${CLUSTER})`);
    return;
  }
  try {
    const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash(
      "confirmed",
    );
    const sig = await conn.requestAirdrop(pubkey, sol * LAMPORTS_PER_SOL);
    await conn.confirmTransaction(
      { signature: sig, blockhash, lastValidBlockHeight },
      "confirmed",
    );
    console.log(`[airdrop] +${sol} SOL to ${pubkey.toBase58()}`);
  } catch (e) {
    console.warn(`[airdrop] failed: ${String(e)}`);
  }
}

export async function fundAccount(
  conn: Connection,
  from: Keypair,
  to: PublicKey,
  lamports: number,
): Promise<void> {
  const tx = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: from.publicKey,
      toPubkey: to,
      lamports,
    }),
  );
  await sendAndConfirmTransaction(conn, tx, [from], {
    commitment: "confirmed",
  });
  console.log(`[fund] ${from.publicKey.toBase58().slice(0, 4)}… → ${to
    .toBase58()
    .slice(0, 4)}… (${lamports} lamports)`);
}

const LINE = "─".repeat(72);
const DLINE = "═".repeat(72);

export function section(title: string): void {
  console.log("\n" + DLINE);
  console.log("  " + title);
  console.log(DLINE);
}

export function step(title: string): void {
  console.log("\n" + LINE);
  console.log("  " + title);
  console.log(LINE);
}

export function info(k: string, v: string | number | bigint): void {
  const pad = k.padEnd(22, " ");
  console.log(`  ${pad} ${v}`);
}

export function shortPk(pk: PublicKey): string {
  const s = pk.toBase58();
  return `${s.slice(0, 4)}…${s.slice(-4)}`;
}

export async function sendAndConfirmPolling(
  conn: Connection,
  tx: Transaction,
  signers: Signer[],
  opts: { commitment?: Commitment; timeoutMs?: number } = {},
): Promise<string> {
  const commitment = opts.commitment ?? "confirmed";
  const timeoutMs = opts.timeoutMs ?? 30_000;

  const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash(
    commitment,
  );
  tx.recentBlockhash = blockhash;
  tx.feePayer = signers[0].publicKey;
  tx.sign(...signers);

  const sig = await conn.sendRawTransaction(tx.serialize(), {
    skipPreflight: false,
    maxRetries: 5,
  });

  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const statuses = await conn.getSignatureStatuses([sig], {
      searchTransactionHistory: false,
    });
    const v = statuses.value[0];
    if (v) {
      if (v.err) {
        throw new Error(
          `Transaction ${sig} failed: ${JSON.stringify(v.err)}`,
        );
      }
      const cs = v.confirmationStatus;
      if (
        cs === "confirmed" ||
        cs === "finalized" ||
        (commitment === "processed" && cs)
      ) {
        return sig;
      }
    }

    const height = await conn.getBlockHeight(commitment);
    if (height > lastValidBlockHeight) {
      throw new Error(`Blockhash expired before confirming ${sig}`);
    }

    await new Promise((r) => setTimeout(r, 800));
  }
  throw new Error(`Confirm timeout for ${sig}`);
}

export function fmtAmount(raw: bigint, decimals: number): string {
  const d = BigInt(decimals);
  const base = 10n ** d;
  const whole = raw / base;
  const frac = (raw % base).toString().padStart(decimals, "0").replace(
    /0+$/,
    "",
  );
  return frac ? `${whole}.${frac}` : whole.toString();
}
