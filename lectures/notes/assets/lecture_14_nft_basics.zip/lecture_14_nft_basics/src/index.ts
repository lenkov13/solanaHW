
import { runSplNftDemo } from "./demos/01_spl_nft";
import { runToken2022NftDemo } from "./demos/02_token2022_nft";
import { runMetaplexMetadataDemo } from "./demos/03_metaplex_metadata";
import { runPrintEditionDemo } from "./demos/04_print_edition";
import { runReadNftDemo } from "./demos/05_read_nft";
import { runCollectionNftDemo } from "./demos/06_collection_nft";

async function main(): Promise<void> {
  console.log(
    "\nЛекция 14 — NFT на Solana: основы. Все демо ниже работают на devnet.\n",
  );

  await runSplNftDemo();
  await runToken2022NftDemo();
  await runMetaplexMetadataDemo();
  await runPrintEditionDemo();
  await runReadNftDemo();
  await runCollectionNftDemo();

  console.log("\nВсе демо завершены.\n");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
