
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  getAssociatedTokenAddressSync,
  getMinimumBalanceForRentExemptMint,
  getMint,
} from "@solana/spl-token";
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Metadata,
  createCreateMasterEditionV3Instruction,
  createCreateMetadataAccountV3Instruction,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";

import {
  CLUSTER,
  info,
  LECTURE_14_BASE_URI,
  loadOrCreatePayer,
  makeConnection,
  section,
  sendAndConfirmPolling,
  shortPk,
  step,
} from "../helpers";

function findMetadataPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findMasterEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

export async function runMetaplexMetadataDemo(): Promise<void> {
  section("Demo 3 — Metaplex Token Metadata (low-level)");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);

  const mintKp = Keypair.generate();
  const mint = mintKp.publicKey;
  const ata = getAssociatedTokenAddressSync(
    mint,
    payer.publicKey,
    false,
    TOKEN_PROGRAM_ID,
    ASSOCIATED_TOKEN_PROGRAM_ID,
  );
  const metadataPda = findMetadataPda(mint);
  const editionPda = findMasterEditionPda(mint);

  step("1. адреса (PDA выводятся детерминированно из mint)");
  info("token metadata program", TOKEN_METADATA_PROGRAM_ID.toBase58());
  info("mint", mint.toBase58());
  info("ata", shortPk(ata));
  info("metadata PDA", metadataPda.toBase58());
  info("masterEdition PDA", editionPda.toBase58());

  step("2. tx #1 — обычный SPL: createAccount + initMint2(0) + ATA + mintTo(1)");
  const mintRent = await getMinimumBalanceForRentExemptMint(conn);
  const tx1 = new Transaction().add(
    SystemProgram.createAccount({
      fromPubkey: payer.publicKey,
      newAccountPubkey: mint,
      space: MINT_SIZE,
      lamports: mintRent,
      programId: TOKEN_PROGRAM_ID,
    }),

    createInitializeMint2Instruction(
      mint,
      0,
      payer.publicKey,
      payer.publicKey,
      TOKEN_PROGRAM_ID,
    ),
    createAssociatedTokenAccountInstruction(
      payer.publicKey,
      ata,
      payer.publicKey,
      mint,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID,
    ),
    createMintToInstruction(
      mint,
      ata,
      payer.publicKey,
      1n,
      [],
      TOKEN_PROGRAM_ID,
    ),
  );
  const sig1 = await sendAndConfirmPolling(conn, tx1, [payer, mintKp]);
  info("tx#1 sig", sig1.slice(0, 12) + "…");

  step("3. tx #2 — CreateMetadataAccountV3: пишем DataV2 в metadata-PDA");
  const metadataIx = createCreateMetadataAccountV3Instruction(
    {
      metadata: metadataPda,
      mint,
      mintAuthority: payer.publicKey,
      payer: payer.publicKey,
      updateAuthority: payer.publicKey,
    },
    {
      createMetadataAccountArgsV3: {
        data: {
          name: "Course NFT — L14 (low-level)",
          symbol: "CRSLOW",
          uri: `${LECTURE_14_BASE_URI}/03_metaplex.json`,
          sellerFeeBasisPoints: 500,
          creators: [
            { address: payer.publicKey, verified: true, share: 100 },
          ],
          collection: null,
          uses: null,
        },
        isMutable: true,
        collectionDetails: null,
      },
    },
  );
  const sig2 = await sendAndConfirmPolling(
    conn,
    new Transaction().add(metadataIx),
    [payer],
  );
  info("tx#2 sig", sig2.slice(0, 12) + "…");

  step(
    "4. tx #3 — CreateMasterEditionV3 (maxSupply=0): фиксируем supply=1 и переносим mintAuthority на edition PDA",
  );
  const editionIx = createCreateMasterEditionV3Instruction(
    {
      edition: editionPda,
      mint,
      updateAuthority: payer.publicKey,
      mintAuthority: payer.publicKey,
      payer: payer.publicKey,
      metadata: metadataPda,
    },
    {
      createMasterEditionArgs: { maxSupply: 0 },
    },
  );
  const sig3 = await sendAndConfirmPolling(
    conn,
    new Transaction().add(editionIx),
    [payer],
  );
  info("tx#3 sig", sig3.slice(0, 12) + "…");

  step("5. читаем mint и metadata напрямую (без SDK)");
  const mintInfo = await getMint(conn, mint, "confirmed", TOKEN_PROGRAM_ID);
  info("decimals", mintInfo.decimals);
  info("supply", mintInfo.supply.toString());
  info("mintAuthority", mintInfo.mintAuthority?.toBase58() ?? "null");
  info("freezeAuthority", mintInfo.freezeAuthority?.toBase58() ?? "null");

  const metaAcc = await conn.getAccountInfo(metadataPda, "confirmed");
  if (!metaAcc) throw new Error("metadata account not found");
  const [meta] = Metadata.deserialize(metaAcc.data);
  info("name", meta.data.name.replace(/\u0000/g, ""));
  info("symbol", meta.data.symbol.replace(/\u0000/g, ""));
  info("uri", meta.data.uri.replace(/\u0000/g, ""));
  info("seller fee bps", meta.data.sellerFeeBasisPoints);
  info("update authority", meta.updateAuthority.toBase58());
  info("is mutable", String(meta.isMutable));

  const explorer =
    `https://explorer.solana.com/address/${mint.toBase58()}` +
    (CLUSTER === "mainnet-beta" ? "" : `?cluster=${CLUSTER}`);
  info("explorer", explorer);

  console.log(
    "\n  Итог: Metaplex Token Metadata = одна программа + два PDA + две инструкции.",
  );
  console.log(
    "       Master Edition держит mintAuthority и freezeAuthority программы — именно так supply навсегда фиксируется в 1.",
  );
}

if (require.main === module) {
  runMetaplexMetadataDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
