
import {
  AuthorityType,
  createAssociatedTokenAccountInstruction,
  createInitializeMetadataPointerInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  createSetAuthorityInstruction,
  ExtensionType,
  getAccount,
  getAssociatedTokenAddressSync,
  getMint,
  getMintLen,
  getTokenMetadata,
  LENGTH_SIZE,
  TOKEN_2022_PROGRAM_ID,
  TYPE_SIZE,
} from "@solana/spl-token";
import {
  createInitializeInstruction,
  pack,
  TokenMetadata,
} from "@solana/spl-token-metadata";
import { Keypair, SystemProgram, Transaction } from "@solana/web3.js";

import {
  fmtAmount,
  info,
  LECTURE_14_BASE_URI,
  loadOrCreatePayer,
  makeConnection,
  section,
  sendAndConfirmPolling,
  shortPk,
  step,
} from "../helpers";

const DECIMALS = 0;

export async function runToken2022NftDemo(): Promise<void> {
  section("Demo 2 — Token-2022 NFT с встроенной Metadata");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);

  const mintKp = Keypair.generate();
  const metadata: TokenMetadata = {
    mint: mintKp.publicKey,
    name: "Course NFT — L14",
    symbol: "CRSNFT",
    uri: `${LECTURE_14_BASE_URI}/02_token2022.json`,
    additionalMetadata: [
      ["category", "education"],
      ["lecture", "14"],
    ],
  };

  step("1. считаем размеры: mintLen + metadataLen");
  const mintLen = getMintLen([ExtensionType.MetadataPointer]);
  const metadataLen = TYPE_SIZE + LENGTH_SIZE + pack(metadata).length;
  const lamports = await conn.getMinimumBalanceForRentExemption(
    mintLen + metadataLen,
  );
  info("mint", mintKp.publicKey.toBase58());
  info("mint len (space)", mintLen);
  info("metadata len", metadataLen);
  info("rent for full", lamports);

  step("2. createAccount → initMetadataPointer → initMint2(0) → initMetadata");
  const initTx = new Transaction().add(
    SystemProgram.createAccount({
      fromPubkey: payer.publicKey,
      newAccountPubkey: mintKp.publicKey,
      space: mintLen,
      lamports,
      programId: TOKEN_2022_PROGRAM_ID,
    }),
    createInitializeMetadataPointerInstruction(
      mintKp.publicKey,
      payer.publicKey,
      mintKp.publicKey,
      TOKEN_2022_PROGRAM_ID,
    ),
    createInitializeMint2Instruction(
      mintKp.publicKey,
      DECIMALS,
      payer.publicKey,
      null,
      TOKEN_2022_PROGRAM_ID,
    ),
    createInitializeInstruction({
      programId: TOKEN_2022_PROGRAM_ID,
      mint: mintKp.publicKey,
      metadata: mintKp.publicKey,
      name: metadata.name,
      symbol: metadata.symbol,
      uri: metadata.uri,
      mintAuthority: payer.publicKey,
      updateAuthority: payer.publicKey,
    }),
  );
  const initSig = await sendAndConfirmPolling(conn, initTx, [payer, mintKp]);
  info("init sig", initSig.slice(0, 12) + "…");

  step("3. createAssociatedTokenAccount + mintTo(1)");
  const ata = getAssociatedTokenAddressSync(
    mintKp.publicKey,
    payer.publicKey,
    false,
    TOKEN_2022_PROGRAM_ID,
  );
  const mintTx = new Transaction().add(
    createAssociatedTokenAccountInstruction(
      payer.publicKey,
      ata,
      payer.publicKey,
      mintKp.publicKey,
      TOKEN_2022_PROGRAM_ID,
    ),
    createMintToInstruction(
      mintKp.publicKey,
      ata,
      payer.publicKey,
      1n,
      [],
      TOKEN_2022_PROGRAM_ID,
    ),
  );
  const mintSig = await sendAndConfirmPolling(conn, mintTx, [payer]);
  info("ata", shortPk(ata));
  info("mint sig", mintSig.slice(0, 12) + "…");

  step("4. setAuthority(MintTokens, null) — supply = 1 фиксируется навсегда");
  const authTx = new Transaction().add(
    createSetAuthorityInstruction(
      mintKp.publicKey,
      payer.publicKey,
      AuthorityType.MintTokens,
      null,
      [],
      TOKEN_2022_PROGRAM_ID,
    ),
  );
  const authSig = await sendAndConfirmPolling(conn, authTx, [payer]);
  info("auth sig", authSig.slice(0, 12) + "…");

  step("5. читаем mint и встроенную metadata, проверяем критерии NFT");
  const mintInfo = await getMint(
    conn,
    mintKp.publicKey,
    "confirmed",
    TOKEN_2022_PROGRAM_ID,
  );
  const ataInfo = await getAccount(
    conn,
    ata,
    "confirmed",
    TOKEN_2022_PROGRAM_ID,
  );
  info("decimals", mintInfo.decimals);
  info("supply", mintInfo.supply.toString());
  info("mintAuthority", mintInfo.mintAuthority?.toBase58() ?? "null");
  info("ata amount", fmtAmount(ataInfo.amount, mintInfo.decimals));

  const onChain = await getTokenMetadata(conn, mintKp.publicKey);
  if (onChain) {
    info("name", onChain.name);
    info("symbol", onChain.symbol);
    info("uri", onChain.uri);
    info(
      "additional",
      onChain.additionalMetadata.map(([k, v]) => `${k}=${v}`).join(", ") ||
        "(empty)",
    );
  }

  const isNft =
    mintInfo.decimals === 0 &&
    mintInfo.supply === 1n &&
    mintInfo.mintAuthority === null &&
    ataInfo.amount === 1n;
  info("verdict", isNft ? "✓ это валидный Token-2022 NFT" : "✗ ещё не NFT");

  console.log(
    "\n  Итог: Token-2022 NFT — самый «честный» формат: всё про токен и его metadata живёт в одном аккаунте.",
  );
  console.log(
    "       Никакой отдельной Metaplex-программы не требуется — кошельки понимают этот формат напрямую.",
  );
}

if (require.main === module) {
  runToken2022NftDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
