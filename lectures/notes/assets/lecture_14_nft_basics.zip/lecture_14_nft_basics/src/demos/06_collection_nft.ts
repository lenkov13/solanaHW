
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  getAssociatedTokenAddressSync,
  getMinimumBalanceForRentExemptMint,
} from "@solana/spl-token";
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Metadata,
  createCreateMasterEditionV3Instruction,
  createCreateMetadataAccountV3Instruction,
  createVerifySizedCollectionItemInstruction,
  isCollectionDetailsV1,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";

import {
  CLUSTER,
  info,
  LECTURE_14_BASE_URI,
  loadOrCreatePayer,
  makeConnection,
  section,
  sendAndConfirmPolling,
  shortPk,
  step,
} from "../helpers";

const COLLECTION_URI = `${LECTURE_14_BASE_URI}/collection.json`;
const NFT_1_URI = `${LECTURE_14_BASE_URI}/nft_1.json`;
const NFT_2_URI = `${LECTURE_14_BASE_URI}/nft_2.json`;

function findMetadataPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

interface NftCreated {
  mint: PublicKey;
  metadataPda: PublicKey;
  editionPda: PublicKey;
}

async function createMasterEditionNft(
  conn: ReturnType<typeof makeConnection>,
  payer: Keypair,
  opts: {
    name: string;
    symbol: string;
    uri: string;
    collection: { key: PublicKey; verified: boolean } | null;
    collectionDetails: { __kind: "V1"; size: number } | null;
    label: string;
  },
): Promise<NftCreated> {
  const mintKp = Keypair.generate();
  const mint = mintKp.publicKey;
  const ata = getAssociatedTokenAddressSync(
    mint,
    payer.publicKey,
    false,
    TOKEN_PROGRAM_ID,
    ASSOCIATED_TOKEN_PROGRAM_ID,
  );
  const metadataPda = findMetadataPda(mint);
  const editionPda = findEditionPda(mint);

  info(`${opts.label} mint`, mint.toBase58());
  info(`${opts.label} metadata PDA`, shortPk(metadataPda));
  info(`${opts.label} edition PDA`, shortPk(editionPda));

  const mintRent = await getMinimumBalanceForRentExemptMint(conn);

  const tx = new Transaction().add(
    SystemProgram.createAccount({
      fromPubkey: payer.publicKey,
      newAccountPubkey: mint,
      space: MINT_SIZE,
      lamports: mintRent,
      programId: TOKEN_PROGRAM_ID,
    }),
    createInitializeMint2Instruction(
      mint,
      0,
      payer.publicKey,
      payer.publicKey,
      TOKEN_PROGRAM_ID,
    ),
    createAssociatedTokenAccountInstruction(
      payer.publicKey,
      ata,
      payer.publicKey,
      mint,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID,
    ),
    createMintToInstruction(
      mint,
      ata,
      payer.publicKey,
      1n,
      [],
      TOKEN_PROGRAM_ID,
    ),
    createCreateMetadataAccountV3Instruction(
      {
        metadata: metadataPda,
        mint,
        mintAuthority: payer.publicKey,
        payer: payer.publicKey,
        updateAuthority: payer.publicKey,
      },
      {
        createMetadataAccountArgsV3: {
          data: {
            name: opts.name,
            symbol: opts.symbol,
            uri: opts.uri,
            sellerFeeBasisPoints: 500,
            creators: [
              { address: payer.publicKey, verified: true, share: 100 },
            ],
            collection: opts.collection,
            uses: null,
          },
          isMutable: true,
          collectionDetails: opts.collectionDetails,
        },
      },
    ),
    createCreateMasterEditionV3Instruction(
      {
        edition: editionPda,
        mint,
        updateAuthority: payer.publicKey,
        mintAuthority: payer.publicKey,
        payer: payer.publicKey,
        metadata: metadataPda,
      },
      {
        createMasterEditionArgs: { maxSupply: 0 },
      },
    ),
  );

  const sig = await sendAndConfirmPolling(conn, tx, [payer, mintKp]);
  info(`${opts.label} tx sig`, sig.slice(0, 12) + "…");

  return { mint, metadataPda, editionPda };
}

export async function runCollectionNftDemo(): Promise<void> {
  section("Demo 6 — Collection NFT + verified members");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);

  step("0. URIs (off-chain JSON в web/public/lecture-14/)");
  info("collection.uri", COLLECTION_URI);
  info("nft_1.uri", NFT_1_URI);
  info("nft_2.uri", NFT_2_URI);

  step(
    "1. tx#1 — создаём COLLECTION NFT (Master Edition + collectionDetails.V1.size=0)",
  );
  const collection = await createMasterEditionNft(conn, payer, {
    name: "Course Collection — L14",
    symbol: "CRSCOL",
    uri: COLLECTION_URI,
    collection: null,
    collectionDetails: { __kind: "V1", size: 0 },
    label: "collection",
  });

  step(
    "2. tx#2 — создаём NFT #1 с collection={ key, verified=false } (это claim, ещё не proof)",
  );
  const nft1 = await createMasterEditionNft(conn, payer, {
    name: "Course NFT #1 — Genesis Block",
    symbol: "CRSCOL",
    uri: NFT_1_URI,
    collection: { key: collection.mint, verified: false },
    collectionDetails: null,
    label: "nft1",
  });

  step(
    "3. tx#3 — VerifySizedCollectionItem #1: подписывает update_authority parent NFT (= payer)",
  );
  const verifyIx1 = createVerifySizedCollectionItemInstruction({
    metadata: nft1.metadataPda,
    collectionAuthority: payer.publicKey,
    payer: payer.publicKey,
    collectionMint: collection.mint,
    collection: collection.metadataPda,
    collectionMasterEditionAccount: collection.editionPda,
  });
  const sigVerify1 = await sendAndConfirmPolling(
    conn,
    new Transaction().add(verifyIx1),
    [payer],
  );
  info("verify #1 sig", sigVerify1.slice(0, 12) + "…");

  step("4. tx#4 — создаём NFT #2 (то же самое, но другой URI и атрибуты)");
  const nft2 = await createMasterEditionNft(conn, payer, {
    name: "Course NFT #2 — Slot Leader",
    symbol: "CRSCOL",
    uri: NFT_2_URI,
    collection: { key: collection.mint, verified: false },
    collectionDetails: null,
    label: "nft2",
  });

  step("5. tx#5 — VerifySizedCollectionItem #2");
  const verifyIx2 = createVerifySizedCollectionItemInstruction({
    metadata: nft2.metadataPda,
    collectionAuthority: payer.publicKey,
    payer: payer.publicKey,
    collectionMint: collection.mint,
    collection: collection.metadataPda,
    collectionMasterEditionAccount: collection.editionPda,
  });
  const sigVerify2 = await sendAndConfirmPolling(
    conn,
    new Transaction().add(verifyIx2),
    [payer],
  );
  info("verify #2 sig", sigVerify2.slice(0, 12) + "…");

  step("6. читаем итоговое состояние трёх Metadata-аккаунтов");

  const collectionAcc = await conn.getAccountInfo(
    collection.metadataPda,
    "confirmed",
  );
  if (!collectionAcc) throw new Error("collection metadata not found");
  const [collectionMeta] = Metadata.deserialize(collectionAcc.data);

  const detailsLabel =
    collectionMeta.collectionDetails &&
    isCollectionDetailsV1(collectionMeta.collectionDetails)
      ? `V1 size=${String(collectionMeta.collectionDetails.size)}`
      : "(none)";
  info("collection.collectionDetails", detailsLabel);

  for (const [label, child] of [
    ["nft1", nft1],
    ["nft2", nft2],
  ] as const) {
    const acc = await conn.getAccountInfo(child.metadataPda, "confirmed");
    if (!acc) throw new Error(`${label} metadata not found`);
    const [meta] = Metadata.deserialize(acc.data);
    const c = meta.collection;
    const collLabel = c
      ? `key=${shortPk(new PublicKey(c.key))}, verified=${c.verified}`
      : "(none)";
    info(`${label}.name`, meta.data.name.replace(/\u0000/g, ""));
    info(`${label}.uri`, meta.data.uri.replace(/\u0000/g, ""));
    info(`${label}.collection`, collLabel);
  }

  const explorer =
    `https://explorer.solana.com/address/${collection.mint.toBase58()}` +
    (CLUSTER === "mainnet-beta" ? "" : `?cluster=${CLUSTER}`);
  info("collection explorer", explorer);

  console.log(
    "\n  Итог: collection — это обычный Master Edition NFT с пометкой collectionDetails.V1.size,",
  );
  console.log(
    "       поле collection в члене коллекции — это claim; verified=true появляется только",
  );
  console.log(
    "       после VerifySizedCollectionItem, подписанного update authority родителя.",
  );
  console.log(
    "       Программа Metaplex автоматически инкрементит size в parent NFT при каждой verify.",
  );
}

if (require.main === module) {
  runCollectionNftDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
