
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Metadata,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  getAccount,
  getMint,
  getTokenMetadata,
  TOKEN_2022_PROGRAM_ID,
  TOKEN_PROGRAM_ID,
} from "@solana/spl-token";
import { Connection, PublicKey } from "@solana/web3.js";

import {
  CLUSTER,
  info,
  loadOrCreatePayer,
  makeConnection,
  section,
  shortPk,
  step,
} from "../helpers";
import { runToken2022NftDemo } from "./02_token2022_nft";

interface ProbeResult {
  programId: PublicKey;
  decimals: number;
  supply: bigint;
  mintAuthority: PublicKey | null;
  freezeAuthority: PublicKey | null;
  owner?: PublicKey;
  ataAmount?: bigint;
  name?: string;
  symbol?: string;
  uri?: string;
  metadataSource: "token-2022" | "metaplex" | "none";

  authorityFix: "revoked-null" | "metaplex-edition" | "open";
}

function findEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

async function detectMintProgram(
  conn: Connection,
  mint: PublicKey,
): Promise<PublicKey> {
  const acc = await conn.getAccountInfo(mint, "confirmed");
  if (!acc) throw new Error(`mint ${mint.toBase58()} not found on-chain`);
  if (acc.owner.equals(TOKEN_PROGRAM_ID)) return TOKEN_PROGRAM_ID;
  if (acc.owner.equals(TOKEN_2022_PROGRAM_ID)) return TOKEN_2022_PROGRAM_ID;
  throw new Error(
    `mint ${mint.toBase58()} owned by неизвестная программа: ${acc.owner.toBase58()}`,
  );
}

async function probeNft(conn: Connection, mint: PublicKey): Promise<ProbeResult> {
  const programId = await detectMintProgram(conn, mint);

  const mintInfo = await getMint(conn, mint, "confirmed", programId);

  const editionPda = findEditionPda(mint);
  let authorityFix: ProbeResult["authorityFix"];
  if (mintInfo.mintAuthority === null) {
    authorityFix = "revoked-null";
  } else if (mintInfo.mintAuthority.equals(editionPda)) {
    authorityFix = "metaplex-edition";
  } else {
    authorityFix = "open";
  }

  const result: ProbeResult = {
    programId,
    decimals: mintInfo.decimals,
    supply: mintInfo.supply,
    mintAuthority: mintInfo.mintAuthority,
    freezeAuthority: mintInfo.freezeAuthority,
    metadataSource: "none",
    authorityFix,
  };

  try {
    const largest = await conn.getTokenLargestAccounts(mint, "confirmed");
    const top = largest.value[0];
    if (top) {
      const ataInfo = await getAccount(
        conn,
        top.address,
        "confirmed",
        programId,
      );
      result.owner = ataInfo.owner;
      result.ataAmount = ataInfo.amount;
    }
  } catch {

  }

  if (programId.equals(TOKEN_2022_PROGRAM_ID)) {
    const m = await getTokenMetadata(conn, mint);
    if (m) {
      result.name = m.name;
      result.symbol = m.symbol;
      result.uri = m.uri;
      result.metadataSource = "token-2022";
    }
  }

  if (result.metadataSource === "none") {

    const metadataPda = PublicKey.findProgramAddressSync(
      [
        Buffer.from("metadata"),
        TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
      ],
      TOKEN_METADATA_PROGRAM_ID,
    )[0];
    const acc = await conn.getAccountInfo(metadataPda, "confirmed");
    if (acc) {
      const [meta] = Metadata.deserialize(acc.data);
      result.name = meta.data.name.replace(/\u0000/g, "");
      result.symbol = meta.data.symbol.replace(/\u0000/g, "");
      result.uri = meta.data.uri.replace(/\u0000/g, "");
      result.metadataSource = "metaplex";
    }
  }

  return result;
}

function isNft(p: ProbeResult): boolean {
  return (
    p.decimals === 0 &&
    p.supply === 1n &&
    p.authorityFix !== "open" &&
    p.ataAmount === 1n
  );
}

export async function runReadNftDemo(): Promise<void> {
  section("Demo 4 — universal read & validate NFT");

  const conn = makeConnection();
  await loadOrCreatePayer(conn);

  const envMint = process.env.NFT_MINT?.trim();
  let mint: PublicKey;

  if (envMint) {
    step("1. читаем mint из NFT_MINT");
    mint = new PublicKey(envMint);
  } else {
    step("1. NFT_MINT не задан — выпускаем Token-2022 NFT для демо (зелёный путь)");
    await runToken2022NftDemo();

    console.log(
      "\n  Подсказка: запустите `NFT_MINT=<address> npm run demo:4`,",
    );
    console.log(
      "             используя адрес mint из вывода demo:2 выше.",
    );
    return;
  }

  step("2. определяем program-owner mint и читаем mint info");
  const probe = await probeNft(conn, mint);
  info("mint", mint.toBase58());
  info("program", probe.programId.equals(TOKEN_2022_PROGRAM_ID) ? "Token-2022" : "Token");
  info("decimals", probe.decimals);
  info("supply", probe.supply.toString());
  info("mintAuthority", probe.mintAuthority?.toBase58() ?? "null");
  info("freezeAuthority", probe.freezeAuthority?.toBase58() ?? "null");

  if (probe.owner) {
    info("owner", shortPk(probe.owner));
    info("ata amount", probe.ataAmount?.toString() ?? "?");
  } else {
    info("owner", "(нет держателя)");
  }

  step("3. metadata");
  info("source", probe.metadataSource);
  if (probe.metadataSource !== "none") {
    info("name", probe.name ?? "");
    info("symbol", probe.symbol ?? "");
    info("uri", probe.uri ?? "");
  } else {
    info("name", "(нет metadata — ни Token-2022, ни Metaplex)");
  }

  step("4. вердикт + explorer");
  const fixLabel: Record<ProbeResult["authorityFix"], string> = {
    "revoked-null": "mintAuthority = null (классический revoke)",
    "metaplex-edition": "mintAuthority = master edition PDA (Metaplex)",
    "open": "mintAuthority открыт — supply не зафиксирован",
  };
  info("authority fix", fixLabel[probe.authorityFix]);
  const verdict = isNft(probe) ? "✓ это валидный NFT" : "✗ не NFT";
  info("verdict", verdict);
  const explorer =
    `https://explorer.solana.com/address/${mint.toBase58()}` +
    (CLUSTER === "mainnet-beta" ? "" : `?cluster=${CLUSTER}`);
  info("explorer", explorer);

  console.log(
    "\n  Итог: для проверки NFT читаем decimals, supply, ataAmount и mintAuthority.",
  );
  console.log(
    "       mintAuthority может быть либо null (SPL/Token-2022 школа), либо master edition PDA (Metaplex школа) —",
  );
  console.log(
    "       обе формы корректно фиксируют supply = 1.",
  );
}

if (require.main === module) {
  runReadNftDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
