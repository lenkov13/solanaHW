
import {
  ASSOCIATED_TOKEN_PROGRAM_ID,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  createAssociatedTokenAccountInstruction,
  createInitializeMint2Instruction,
  createMintToInstruction,
  getAssociatedTokenAddressSync,
  getMint,
  getMinimumBalanceForRentExemptMint,
} from "@solana/spl-token";
import {
  PROGRAM_ID as TOKEN_METADATA_PROGRAM_ID,
  Edition,
  MasterEditionV2,
  createCreateMasterEditionV3Instruction,
  createCreateMetadataAccountV3Instruction,
  createMintNewEditionFromMasterEditionViaTokenInstruction,
} from "@metaplex-foundation/mpl-token-metadata";
import {
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
} from "@solana/web3.js";

import {
  CLUSTER,
  info,
  LECTURE_14_BASE_URI,
  loadOrCreatePayer,
  makeConnection,
  section,
  sendAndConfirmPolling,
  shortPk,
  step,
} from "../helpers";

function findMetadataPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findEditionPda(mint: PublicKey): PublicKey {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      mint.toBuffer(),
      Buffer.from("edition"),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

function findEditionMarkerPda(masterMint: PublicKey, edition: bigint): PublicKey {
  const page = (edition / 248n).toString();
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from("metadata"),
      TOKEN_METADATA_PROGRAM_ID.toBuffer(),
      masterMint.toBuffer(),
      Buffer.from("edition"),
      Buffer.from(page),
    ],
    TOKEN_METADATA_PROGRAM_ID,
  )[0];
}

const SERIES_MAX_SUPPLY = 3;
const PRINTS_TO_MINT = 2;

export async function runPrintEditionDemo(): Promise<void> {
  section("Demo 4 — Print Editions (numbered series)");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);

  const masterKp = Keypair.generate();
  const masterMint = masterKp.publicKey;
  const masterAta = getAssociatedTokenAddressSync(
    masterMint,
    payer.publicKey,
    false,
    TOKEN_PROGRAM_ID,
    ASSOCIATED_TOKEN_PROGRAM_ID,
  );
  const masterMetadataPda = findMetadataPda(masterMint);
  const masterEditionPda = findEditionPda(masterMint);

  step(`1. готовим series master (maxSupply = ${SERIES_MAX_SUPPLY})`);
  info("master mint", masterMint.toBase58());
  info("master metadata PDA", masterMetadataPda.toBase58());
  info("master edition PDA", masterEditionPda.toBase58());

  const mintRent = await getMinimumBalanceForRentExemptMint(conn);
  const tx0 = new Transaction().add(
    SystemProgram.createAccount({
      fromPubkey: payer.publicKey,
      newAccountPubkey: masterMint,
      space: MINT_SIZE,
      lamports: mintRent,
      programId: TOKEN_PROGRAM_ID,
    }),
    createInitializeMint2Instruction(
      masterMint,
      0,
      payer.publicKey,
      payer.publicKey,
      TOKEN_PROGRAM_ID,
    ),
    createAssociatedTokenAccountInstruction(
      payer.publicKey,
      masterAta,
      payer.publicKey,
      masterMint,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID,
    ),
    createMintToInstruction(
      masterMint,
      masterAta,
      payer.publicKey,
      1n,
      [],
      TOKEN_PROGRAM_ID,
    ),
    createCreateMetadataAccountV3Instruction(
      {
        metadata: masterMetadataPda,
        mint: masterMint,
        mintAuthority: payer.publicKey,
        payer: payer.publicKey,
        updateAuthority: payer.publicKey,
      },
      {
        createMetadataAccountArgsV3: {
          data: {
            name: "Course Series — L14",
            symbol: "CRSER",
                uri: `${LECTURE_14_BASE_URI}/04_print_series.json`,
            sellerFeeBasisPoints: 500,
            creators: [
              { address: payer.publicKey, verified: true, share: 100 },
            ],
            collection: null,
            uses: null,
          },
          isMutable: true,
          collectionDetails: null,
        },
      },
    ),
    createCreateMasterEditionV3Instruction(
      {
        edition: masterEditionPda,
        mint: masterMint,
        updateAuthority: payer.publicKey,
        mintAuthority: payer.publicKey,
        payer: payer.publicKey,
        metadata: masterMetadataPda,
      },
      {
        createMasterEditionArgs: { maxSupply: SERIES_MAX_SUPPLY },
      },
    ),
  );
  const sigMaster = await sendAndConfirmPolling(conn, tx0, [payer, masterKp]);
  info("master tx sig", sigMaster.slice(0, 12) + "…");

  const prints: Array<{ mint: PublicKey; edition: bigint }> = [];

  for (let n = 1n; n <= BigInt(PRINTS_TO_MINT); n++) {
    step(`2.${n}. печатаем edition #${n} из ${SERIES_MAX_SUPPLY}`);

    const newMintKp = Keypair.generate();
    const newMint = newMintKp.publicKey;
    const newAta = getAssociatedTokenAddressSync(
      newMint,
      payer.publicKey,
      false,
      TOKEN_PROGRAM_ID,
      ASSOCIATED_TOKEN_PROGRAM_ID,
    );
    const newMetadataPda = findMetadataPda(newMint);
    const newEditionPda = findEditionPda(newMint);
    const editionMarkerPda = findEditionMarkerPda(masterMint, n);

    info("new mint", newMint.toBase58());
    info("editionMarker PDA", editionMarkerPda.toBase58());

    const txPrint = new Transaction().add(

      SystemProgram.createAccount({
        fromPubkey: payer.publicKey,
        newAccountPubkey: newMint,
        space: MINT_SIZE,
        lamports: mintRent,
        programId: TOKEN_PROGRAM_ID,
      }),
      createInitializeMint2Instruction(
        newMint,
        0,
        payer.publicKey,
        payer.publicKey,
        TOKEN_PROGRAM_ID,
      ),
      createAssociatedTokenAccountInstruction(
        payer.publicKey,
        newAta,
        payer.publicKey,
        newMint,
        TOKEN_PROGRAM_ID,
        ASSOCIATED_TOKEN_PROGRAM_ID,
      ),
      createMintToInstruction(
        newMint,
        newAta,
        payer.publicKey,
        1n,
        [],
        TOKEN_PROGRAM_ID,
      ),

      createMintNewEditionFromMasterEditionViaTokenInstruction(
        {
          newMetadata: newMetadataPda,
          newEdition: newEditionPda,
          masterEdition: masterEditionPda,
          newMint,
          editionMarkPda: editionMarkerPda,
          newMintAuthority: payer.publicKey,
          payer: payer.publicKey,
          tokenAccountOwner: payer.publicKey,
          tokenAccount: masterAta,
          newMetadataUpdateAuthority: payer.publicKey,
          metadata: masterMetadataPda,
        },
        {
          mintNewEditionFromMasterEditionViaTokenArgs: { edition: n },
        },
      ),
    );

    const sigPrint = await sendAndConfirmPolling(conn, txPrint, [
      payer,
      newMintKp,
    ]);
    info("print tx sig", sigPrint.slice(0, 12) + "…");

    prints.push({ mint: newMint, edition: n });
  }

  step("3. читаем master edition (supply должен быть = 2)");
  const masterAcc = await conn.getAccountInfo(masterEditionPda, "confirmed");
  if (!masterAcc) throw new Error("master edition not found");
  const [masterEdition] = MasterEditionV2.deserialize(masterAcc.data);
  info("master.supply", String(masterEdition.supply));
  info("master.maxSupply", String(masterEdition.maxSupply ?? "null"));
  info("master.key", String(masterEdition.key));

  step("4. читаем каждый Print: parent + номер");
  for (const { mint: copyMint, edition: n } of prints) {
    const editionAcc = await conn.getAccountInfo(
      findEditionPda(copyMint),
      "confirmed",
    );
    if (!editionAcc) throw new Error(`edition #${n} account not found`);
    const [edition] = Edition.deserialize(editionAcc.data);
    info(
      `print #${n}`,
      `mint=${shortPk(copyMint)}, parent=${shortPk(
        new PublicKey(edition.parent),
      )}, edition=${String(edition.edition)}, key=${String(edition.key)}`,
    );

    const copyMintInfo = await getMint(
      conn,
      copyMint,
      "confirmed",
      TOKEN_PROGRAM_ID,
    );
    info(
      `print #${n} mint`,
      `decimals=${copyMintInfo.decimals}, supply=${String(
        copyMintInfo.supply,
      )}, mintAuthority=${
        copyMintInfo.mintAuthority?.toBase58() ?? "null"
      }`,
    );
  }

  const explorer =
    `https://explorer.solana.com/address/${masterMint.toBase58()}` +
    (CLUSTER === "mainnet-beta" ? "" : `?cluster=${CLUSTER}`);
  info("master explorer", explorer);

  console.log(
    `\n  Итог: одна транзакция Print Edition создаёт целый «мини-NFT» — новый mint, новую Metadata (с копией name/symbol/uri),`,
  );
  console.log(
    `       новый Edition PDA (key = EditionV1) и обновляет битовую карту editionMarker. Supply на Master инкрементится автоматически.`,
  );
  console.log(
    `       Когда supply == maxSupply (${SERIES_MAX_SUPPLY}), программа Metaplex отказывает в дальнейших печатях.`,
  );
}

if (require.main === module) {
  runPrintEditionDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
