
import {
  AuthorityType,
  createAssociatedTokenAccount,
  createMint,
  getAccount,
  getMint,
  mintTo,
  setAuthority,
  TOKEN_PROGRAM_ID,
} from "@solana/spl-token";

import {
  fmtAmount,
  info,
  loadOrCreatePayer,
  makeConnection,
  section,
  shortPk,
  step,
} from "../helpers";

export async function runSplNftDemo(): Promise<void> {
  section("Demo 1 — SPL classic NFT (Token Program, без Metaplex)");

  const conn = makeConnection();
  const payer = await loadOrCreatePayer(conn);

  step("1. createMint(decimals = 0, mintAuthority = payer, freeze = null)");
  const mint = await createMint(
    conn,
    payer,
    payer.publicKey,
    null,
    0,
    undefined,
    { commitment: "confirmed" },
    TOKEN_PROGRAM_ID,
  );
  info("mint", mint.toBase58());

  step("2. createAssociatedTokenAccount(owner = payer)");
  const ata = await createAssociatedTokenAccount(
    conn,
    payer,
    mint,
    payer.publicKey,
    { commitment: "confirmed" },
    TOKEN_PROGRAM_ID,
  );
  info("ata", shortPk(ata));

  step("3. mintTo(ata, 1)");
  await mintTo(
    conn,
    payer,
    mint,
    ata,
    payer,
    1n,
    [],
    { commitment: "confirmed" },
    TOKEN_PROGRAM_ID,
  );

  step("4. setAuthority(MintTokens, null) — supply = 1 фиксируется навсегда");
  await setAuthority(
    conn,
    payer,
    mint,
    payer,
    AuthorityType.MintTokens,
    null,
    [],
    { commitment: "confirmed" },
    TOKEN_PROGRAM_ID,
  );

  step("5. читаем mint и ATA, проверяем критерии NFT");
  const mintInfo = await getMint(conn, mint, "confirmed", TOKEN_PROGRAM_ID);
  const ataInfo = await getAccount(conn, ata, "confirmed", TOKEN_PROGRAM_ID);
  info("decimals", mintInfo.decimals);
  info("supply", mintInfo.supply.toString());
  info("mintAuthority", mintInfo.mintAuthority?.toBase58() ?? "null");
  info("freezeAuthority", mintInfo.freezeAuthority?.toBase58() ?? "null");
  info("ata amount", fmtAmount(ataInfo.amount, mintInfo.decimals));

  const isNft =
    mintInfo.decimals === 0 &&
    mintInfo.supply === 1n &&
    mintInfo.mintAuthority === null &&
    ataInfo.amount === 1n;
  info("verdict", isNft ? "✓ это валидный SPL NFT" : "✗ ещё не NFT");

  console.log(
    "\n  Итог: NFT — это паттерн использования mint, а не отдельный тип аккаунта.",
  );
  console.log(
    "       Чтобы превратить токен в NFT, достаточно decimals=0, mintTo(1) и revoke mint authority.",
  );
}

if (require.main === module) {
  runSplNftDemo().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
